CREATE TABLE `articles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`scanId` int NOT NULL,
	`title` text NOT NULL,
	`source` varchar(255) NOT NULL,
	`url` text NOT NULL,
	`summary` text,
	`publishedDate` varchar(32),
	`score` int NOT NULL DEFAULT 0,
	`priority` enum('HIGH','MEDIUM','LOW','SKIP') NOT NULL DEFAULT 'SKIP',
	`scoringReasons` text,
	`adaptationAngle` text,
	`isAdapted` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `articles_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `content_pieces` (
	`id` int AUTO_INCREMENT NOT NULL,
	`articleId` int NOT NULL,
	`platform` enum('linkedin','instagram','tiktok','facebook','x','threads','pinterest','newsletter') NOT NULL,
	`variantId` varchar(64) NOT NULL,
	`variantLabel` varchar(128) NOT NULL,
	`outputType` enum('text','image','video','both') NOT NULL DEFAULT 'text',
	`textContent` text,
	`imageUrl` text,
	`format` varchar(128) NOT NULL,
	`dimensions` varchar(64) NOT NULL,
	`isFavorite` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `content_pieces_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `custom_feeds` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`url` text NOT NULL,
	`category` varchar(128) NOT NULL DEFAULT 'Custom',
	`isActive` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `custom_feeds_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `feed_scans` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`scanDate` timestamp NOT NULL DEFAULT (now()),
	`totalArticles` int NOT NULL DEFAULT 0,
	`highCount` int NOT NULL DEFAULT 0,
	`mediumCount` int NOT NULL DEFAULT 0,
	`lowCount` int NOT NULL DEFAULT 0,
	`skipCount` int NOT NULL DEFAULT 0,
	`daysBack` int NOT NULL DEFAULT 3,
	`sourceMode` enum('scanner','text','url') NOT NULL DEFAULT 'scanner',
	`status` enum('running','completed','failed') NOT NULL DEFAULT 'running',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `feed_scans_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `users` (
	`id` int AUTO_INCREMENT NOT NULL,
	`openId` varchar(64) NOT NULL,
	`name` text,
	`email` varchar(320),
	`loginMethod` varchar(64),
	`role` enum('user','admin') NOT NULL DEFAULT 'user',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`lastSignedIn` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `users_id` PRIMARY KEY(`id`),
	CONSTRAINT `users_openId_unique` UNIQUE(`openId`)
);
