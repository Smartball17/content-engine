CREATE TABLE `brand_profiles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`brandId` varchar(64) NOT NULL,
	`name` varchar(255) NOT NULL,
	`profileJson` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `brand_profiles_id` PRIMARY KEY(`id`)
);
