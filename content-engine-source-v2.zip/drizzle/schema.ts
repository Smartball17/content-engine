import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const feedScans = mysqlTable("feed_scans", {
  id: int("id").autoincrement().primaryKey(),
  ownerId: int("ownerId").notNull(),
  scanDate: timestamp("scanDate").defaultNow().notNull(),
  totalArticles: int("totalArticles").default(0).notNull(),
  highCount: int("highCount").default(0).notNull(),
  mediumCount: int("mediumCount").default(0).notNull(),
  lowCount: int("lowCount").default(0).notNull(),
  skipCount: int("skipCount").default(0).notNull(),
  daysBack: int("daysBack").default(3).notNull(),
  sourceMode: mysqlEnum("sourceMode", ["scanner", "text", "url"]).default("scanner").notNull(),
  status: mysqlEnum("status", ["running", "completed", "failed"]).default("running").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const articles = mysqlTable("articles", {
  id: int("id").autoincrement().primaryKey(),
  scanId: int("scanId").notNull(),
  title: text("title").notNull(),
  source: varchar("source", { length: 255 }).notNull(),
  url: text("url").notNull(),
  summary: text("summary"),
  publishedDate: varchar("publishedDate", { length: 32 }),
  score: int("score").default(0).notNull(),
  priority: mysqlEnum("priority", ["HIGH", "MEDIUM", "LOW", "SKIP"]).default("SKIP").notNull(),
  scoringReasons: text("scoringReasons"),
  adaptationAngle: text("adaptationAngle"),
  isAdapted: int("isAdapted").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const contentPieces = mysqlTable("content_pieces", {
  id: int("id").autoincrement().primaryKey(),
  articleId: int("articleId").notNull(),
  brandId: varchar("brandId", { length: 64 }).default("smartball").notNull(),
  platform: mysqlEnum("platform", ["linkedin", "instagram", "tiktok", "facebook", "x", "threads", "pinterest", "newsletter"]).notNull(),
  variantId: varchar("variantId", { length: 64 }).notNull(),
  variantLabel: varchar("variantLabel", { length: 128 }).notNull(),
  contentTemplate: varchar("contentTemplate", { length: 64 }).default("no_template").notNull(),
  outputType: mysqlEnum("outputType", ["text", "image", "video", "both"]).default("text").notNull(),
  textContent: text("textContent"),
  imageUrl: text("imageUrl"),
  format: varchar("format", { length: 128 }).notNull(),
  dimensions: varchar("dimensions", { length: 64 }).notNull(),
  isFavorite: int("isFavorite").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const customFeeds = mysqlTable("custom_feeds", {
  id: int("id").autoincrement().primaryKey(),
  ownerId: int("ownerId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  url: text("url").notNull(),
  category: varchar("category", { length: 128 }).default("Custom").notNull(),
  isActive: int("isActive").default(1).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const brandProfiles = mysqlTable("brand_profiles", {
  id: int("id").autoincrement().primaryKey(),
  ownerId: int("ownerId").notNull(),
  brandId: varchar("brandId", { length: 64 }).notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  profileJson: text("profileJson").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type FeedScan = typeof feedScans.$inferSelect;
export type InsertFeedScan = typeof feedScans.$inferInsert;
export type Article = typeof articles.$inferSelect;
export type InsertArticle = typeof articles.$inferInsert;
export type ContentPiece = typeof contentPieces.$inferSelect;
export type InsertContentPiece = typeof contentPieces.$inferInsert;
export type CustomFeed = typeof customFeeds.$inferSelect;
export type InsertCustomFeed = typeof customFeeds.$inferInsert;
export type BrandProfileRow = typeof brandProfiles.$inferSelect;
export type InsertBrandProfile = typeof brandProfiles.$inferInsert;
