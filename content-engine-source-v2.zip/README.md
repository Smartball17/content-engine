# Content Engine

AI editorial studio that turns signals, URLs and ideas into on-brand content for every channel.

## What it does

- Discover signals through RSS scanning, free text and public URL import.
- Apply a selectable Brand Identity, including imported JSON/ZIP profiles.
- Generate text, image, video-script and combined outputs for LinkedIn, Instagram, TikTok, Facebook, X, Threads, Pinterest and Newsletter.
- Review, favourite, filter and export pieces from the Library as JSON, ZIP, PDF or DOCX.
- Persist scans, articles, profiles and pieces in MySQL through authenticated tRPC procedures.

## Stack

React 19, Tailwind 4, tRPC 11, Express 4, Drizzle ORM and MySQL/TiDB.

## Run locally in Manus WebDev

```bash
pnpm install
pnpm check
pnpm test
pnpm build
```

Runtime integrations use the environment variables provided by Manus WebDev. Never commit `.env` files or credentials.

## Honest scope

This repository represents a validated functional beta. It is not presented as production-scale SaaS yet. See `docs/PRODUCTION_READINESS_AUDIT.md` for the remaining work around rate limiting, operational observability, dependency remediation, export hardening and production integration contracts.

## Product vs. content brand

**Content Engine** is the product identity. **SMARTBALL** is one selectable Brand Identity used by the generator; other brands can be imported through Brand Studio.

## License

MIT. Third-party services, models, fonts and generated outputs remain subject to their own terms.
