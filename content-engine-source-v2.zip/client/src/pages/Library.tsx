import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { BookOpen, Download, Heart, Loader2, Search } from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { useLocale } from "@/lib/i18n";

const platformOptions = ["all", "linkedin", "instagram", "tiktok", "facebook", "x", "threads", "pinterest", "newsletter"] as const;
const typeOptions = ["all", "text", "image", "video", "both"] as const;

function LibrarySkeleton() {
  return (
    <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3 animate-pulse">
      {[1, 2, 3, 4, 5, 6].map(i => (
        <div key={i} className="rounded-xl border border-border bg-card overflow-hidden">
          <div className="aspect-video bg-muted" />
          <div className="p-4 space-y-2">
            <div className="h-4 w-24 rounded bg-muted" />
            <div className="h-3 w-32 rounded bg-muted" />
            <div className="h-3 w-full rounded bg-muted" />
            <div className="h-3 w-2/3 rounded bg-muted" />
          </div>
        </div>
      ))}
    </div>
  );
}

export default function Library() {
  const { t } = useLocale();
  const utils = trpc.useUtils();
  const library = trpc.curator.library.useQuery();
  const favorite = trpc.curator.toggleFavorite.useMutation({
    onSuccess: () => utils.curator.library.invalidate(),
    onError: e => toast.error(e.message),
  });

  const [query, setQuery] = useState("");
  const [platform, setPlatform] = useState<string>("all");
  const [type, setType] = useState<string>("all");
  const [exporting, setExporting] = useState(false);

  const downloadJson = (filename: string, payload: unknown) => {
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = filename;
    anchor.click();
    URL.revokeObjectURL(url);
  };

  const downloadImage = (url: string, platform: string, id: number) => {
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.target = "_blank";
    anchor.rel = "noreferrer";
    anchor.download = `${platform}-${id}.png`;
    anchor.click();
  };

  const downloadBlob = (blob: Blob, filename: string) => {
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = filename;
    anchor.click();
    URL.revokeObjectURL(url);
  };

  const exportZip = async () => {
    if (!filtered.length) return;
    setExporting(true);
    try {
      const { default: JSZip } = await import("jszip");
      const zip = new JSZip();
      zip.file("README.txt", `${t("exportReadme")}\n\n${t("exportReadmeDetails")}`);
      zip.file("manifest.json", JSON.stringify({ exportedAt: new Date().toISOString(), total: filtered.length, source: "SMARTBALL Content Engine" }, null, 2));
      for (const piece of filtered) {
        zip.file(`pieces/${piece.id}-${piece.platform}.json`, JSON.stringify(piece, null, 2));
        if (piece.textContent) zip.file(`pieces/${piece.id}-${piece.platform}.txt`, piece.textContent);
        if (piece.imageUrl) {
          try {
            const response = await fetch(piece.imageUrl);
            if (response.ok) zip.file(`images/${piece.id}-${piece.platform}.png`, await response.blob());
            else zip.file(`images/${piece.id}-${piece.platform}-source.txt`, piece.imageUrl);
          } catch {
            zip.file(`images/${piece.id}-${piece.platform}-source.txt`, piece.imageUrl);
          }
        }
      }
      downloadBlob(await zip.generateAsync({ type: "blob" }), `content-engine-${new Date().toISOString().slice(0, 10)}.zip`);
      toast.success(t("exportComplete"));
    } catch (error) {
      toast.error(error instanceof Error ? error.message : t("exportFailed"));
    } finally {
      setExporting(false);
    }
  };

  const exportPdf = async () => {
    if (!filtered.length) return;
    const { jsPDF } = await import("jspdf");
    const pdf = new jsPDF({ unit: "pt", format: "a4" });
    const margin = 42;
    let y = 48;
    pdf.setFontSize(20);
    pdf.text(t("libraryTitle"), margin, y);
    y += 24;
    pdf.setFontSize(9);
    pdf.setTextColor(100);
    pdf.text(`${filtered.length} · ${new Date().toLocaleDateString()}`, margin, y);
    y += 28;
    filtered.forEach((piece, index) => {
      if (y > 760) { pdf.addPage(); y = 48; }
      pdf.setTextColor(20);
      pdf.setFontSize(12);
      pdf.text(`${index + 1}. ${piece.platform} · ${piece.variantLabel}`, margin, y);
      y += 16;
      pdf.setFontSize(9);
      pdf.setTextColor(80);
      const lines = pdf.splitTextToSize(piece.textContent || piece.imageUrl || "Visual output", 510);
      pdf.text(lines, margin, y);
      y += Math.max(28, lines.length * 12) + 16;
    });
    pdf.save(`content-engine-${new Date().toISOString().slice(0, 10)}.pdf`);
    toast.success(t("exportComplete"));
  };

  const exportDocx = async () => {
    if (!filtered.length) return;
    const { Document, HeadingLevel, Packer, Paragraph, TextRun } = await import("docx");
    const children = [new Paragraph({ text: t("libraryTitle"), heading: HeadingLevel.TITLE }), new Paragraph({ text: `${filtered.length} · ${new Date().toLocaleDateString()}` })];
    filtered.forEach((piece, index) => {
      children.push(new Paragraph({ text: `${index + 1}. ${piece.platform} · ${piece.variantLabel}`, heading: HeadingLevel.HEADING_2 }));
      children.push(new Paragraph({ children: [new TextRun(piece.textContent || piece.imageUrl || "Visual output")] }));
      children.push(new Paragraph({ text: "" }));
    });
    const blob = await Packer.toBlob(new Document({ sections: [{ children }] }));
    downloadBlob(blob, `content-engine-${new Date().toISOString().slice(0, 10)}.docx`);
    toast.success(t("exportComplete"));
  };

  const filtered = useMemo(() => {
    if (!library.data) return [];
    return library.data.filter(piece => {
      if (platform !== "all" && piece.platform !== platform) return false;
      if (type !== "all" && piece.outputType !== type) return false;
      if (query.trim()) {
        const q = query.toLowerCase();
        const inText = piece.textContent?.toLowerCase().includes(q);
        const inPlatform = piece.platform.toLowerCase().includes(q);
        if (!inText && !inPlatform) return false;
      }
      return true;
    });
  }, [library.data, platform, type, query]);

  return (
    <div className="px-6 py-8 lg:px-10">
      <div className="mx-auto max-w-5xl">
        <header className="mb-8">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <h1>{t("libraryTitle")}</h1>
              <p className="mt-2 text-muted-foreground">{t("libraryDescription")}</p>
            </div>
            <div className="rounded-xl border border-primary/20 bg-primary/[0.05] p-2.5">
              <p className="mb-2 px-1 text-[10px] font-semibold uppercase tracking-[0.16em] text-primary">{t("downloadPieces")}</p>
              <div className="flex flex-wrap gap-1.5">
                <Button variant="outline" size="sm" className="shrink-0 bg-background" disabled={!filtered.length} onClick={() => downloadJson(`content-engine-${new Date().toISOString().slice(0, 10)}.json`, filtered)}><Download className="mr-1.5 h-3.5 w-3.5" />{t("downloadJsonLabel")}</Button>
                <Button variant="outline" size="sm" className="shrink-0 bg-background" disabled={!filtered.length || exporting} onClick={exportZip}><Download className="mr-1.5 h-3.5 w-3.5" />{t("downloadZipLabel")}</Button>
                <Button variant="outline" size="sm" className="shrink-0 bg-background" disabled={!filtered.length} onClick={exportPdf}><Download className="mr-1.5 h-3.5 w-3.5" />{t("downloadPdfLabel")}</Button>
                <Button variant="outline" size="sm" className="shrink-0 bg-background" disabled={!filtered.length} onClick={exportDocx}><Download className="mr-1.5 h-3.5 w-3.5" />{t("downloadDocxLabel")}</Button>
              </div>
              <p className="mt-2 px-1 text-[11px] text-muted-foreground">{t("downloadPiecesDescription")}</p>
            </div>
          </div>
        </header>

        {/* Filters */}
        <div className="mb-6 flex flex-wrap items-center gap-3">
          <div className="relative flex-1 min-w-48">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder={t("searchPieces")}
              className="pl-9 h-10 bg-background border-border text-foreground placeholder:text-muted-foreground/50"
            />
          </div>
          <div className="flex flex-wrap gap-1.5">
            {platformOptions.map(opt => (
              <button
                key={opt}
                onClick={() => setPlatform(opt)}
                className={`rounded-md border px-2.5 py-1.5 text-xs capitalize transition-all duration-150 ${
                  platform === opt
                    ? "border-primary bg-primary/10 text-foreground"
                    : "border-border text-muted-foreground hover:border-primary/30"
                }`}
              >{opt === "all" ? t("all") : opt}</button>
            ))}
          </div>
          <div className="flex flex-wrap gap-1.5">
            {typeOptions.map(opt => (
              <button
                key={opt}
                onClick={() => setType(opt)}
                className={`rounded-md border px-2.5 py-1.5 text-xs capitalize transition-all duration-150 ${
                  type === opt
                    ? "border-primary bg-primary/10 text-foreground"
                    : "border-border text-muted-foreground hover:border-primary/30"
                }`}
              >{opt === "all" ? t("all") : opt === "text" ? t("text") : opt === "image" ? t("image") : opt === "video" ? t("video") : t("both")}</button>
            ))}
          </div>
        </div>

        {library.isLoading ? (
          <LibrarySkeleton />
        ) : (
          <>
            {filtered.length > 0 && (
              <p className="mb-4 text-xs text-muted-foreground">{filtered.length} {t("piecesCount")}</p>
            )}
            <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
              {filtered.map(piece => (
                <Card key={piece.id} className="border-border bg-card overflow-hidden group">
                  {piece.imageUrl && (
                    <img src={piece.imageUrl} alt={`${piece.platform} output`} className="w-full aspect-video object-cover" />
                  )}
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <p className="text-sm font-medium capitalize">{piece.platform}</p>
                        <p className="mt-0.5 text-[11px] text-muted-foreground">{piece.variantLabel} · {piece.dimensions}</p>
                        <p className="mt-1 text-[10px] font-medium uppercase tracking-wider text-primary">{piece.brandId || "smartball"}</p>
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => favorite.mutate({ id: piece.id })}
                        className={piece.isFavorite ? "text-rose-400" : "text-muted-foreground hover:text-rose-300"}
                      >
                        <Heart className={`h-4 w-4 ${piece.isFavorite ? "fill-current" : ""}`} />
                      </Button>
                    </div>
                    <div className="mt-3 flex items-center gap-2 border-t border-border pt-3">
                      <button onClick={() => downloadJson(`${piece.platform}-${piece.id}.json`, piece)} className="inline-flex items-center gap-1.5 text-[11px] font-medium text-muted-foreground hover:text-foreground">
                        <Download className="h-3.5 w-3.5" />{t("downloadJson")}
                      </button>
                      {piece.imageUrl && (
                        <button onClick={() => downloadImage(piece.imageUrl!, piece.platform, piece.id)} className="inline-flex items-center gap-1.5 text-[11px] font-medium text-muted-foreground hover:text-foreground">
                          <Download className="h-3.5 w-3.5" />{t("downloadImage")}
                        </button>
                      )}
                    </div>
                    {piece.textContent && (
                      <p className="mt-3 line-clamp-5 whitespace-pre-wrap text-xs text-muted-foreground leading-relaxed">{piece.textContent}</p>
                    )}
                  </CardContent>
                </Card>
              ))}
              {!filtered.length && (
                <div className="col-span-full rounded-xl border border-dashed border-border py-16 text-center">
                  <BookOpen className="mx-auto h-8 w-8 text-muted-foreground/30" />
                  <p className="mt-3 text-sm text-muted-foreground">
                    {library.data?.length ? t("noFilteredPieces") : t("noSavedPieces")}
                  </p>
                </div>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
