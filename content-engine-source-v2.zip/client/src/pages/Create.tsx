import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Check, ChevronLeft, Download, FileText, Image, Loader2, Pencil, Sparkles, Upload, Video } from "lucide-react";
import { useRef, useState } from "react";
import { toast } from "sonner";
import { useLocation, useSearch } from "wouter";
import { Textarea } from "@/components/ui/textarea";
import { useLocale } from "@/lib/i18n";

const platforms = [
  ["linkedin", "LinkedIn"], ["instagram", "Instagram"], ["tiktok", "TikTok"],
  ["facebook", "Facebook"], ["x", "X / Twitter"], ["threads", "Threads"],
  ["pinterest", "Pinterest"], ["newsletter", "Newsletter"],
] as const;

const templates = [
  ["no_template", "Sin plantilla"], ["product_launch", "Product Launch"], ["case_study", "Case Study"],
  ["thought_leadership", "Thought Leadership"], ["industry_news", "Industry News"],
  ["how_to_guide", "How-To Guide"], ["data_insight", "Data Insight"],
] as const;

type Output = "text" | "image" | "video" | "both";

export default function Create() {
  const [, navigate] = useLocation();
  const { t } = useLocale();
  const search = useSearch();
  const articleId = Number(new URLSearchParams(search).get("article"));
  const queryBrand = new URLSearchParams(search).get("brand");
  const utils = trpc.useUtils();

  const article = trpc.curator.article.useQuery({ articleId }, { enabled: !!articleId });
  const brandProfiles = trpc.curator.brandProfiles.useQuery();
  const [selectedPlatforms, setSelectedPlatforms] = useState<string[]>(["linkedin"]);
  const [outputType, setOutputType] = useState<Output>("text");
  const [contentTemplate, setContentTemplate] = useState("no_template");
  const [selectedBrandId, setSelectedBrandId] = useState(() => {
    try { return queryBrand || localStorage.getItem("content-engine-active-brand") || "smartball"; } catch { return queryBrand || "smartball"; }
  });
  const [confirmed, setConfirmed] = useState(false);
  const [brief, setBrief] = useState("");
  const [showBrief, setShowBrief] = useState(false);
  const [generationLanguage, setGenerationLanguage] = useState<"es" | "en">("es");
  const brandFileInput = useRef<HTMLInputElement>(null);

  const generate = trpc.curator.generate.useMutation({
    onSuccess: data => {
      toast.success(`${data.totalPieces} ${t("piecesGenerated")}`);
      utils.curator.article.invalidate();
      utils.curator.library.invalidate();
    },
    onError: e => toast.error(e.message),
  });
  const importBrand = trpc.curator.importBrandProfile.useMutation({
    onSuccess: data => {
      toast.success(`${data.brand.name} · ${t("brandImported")}`);
      utils.curator.brandProfiles.invalidate();
      setSelectedBrandId(data.brand.id);
      try { localStorage.setItem("content-engine-active-brand", data.brand.id); } catch { /* optional */ }
    },
    onError: e => toast.error(e.message),
  });

  const pieces = article.data?.pieces || [];
  const selectedPlatformLabel = platforms.find(([id]) => id === selectedPlatforms[0])?.[1] || "LinkedIn";
  const togglePlatform = (id: string) => { setConfirmed(false); setSelectedPlatforms(c => c.includes(id) ? c.filter(x => x !== id) : [...c, id]); };
  const needsConfirm = selectedPlatforms.length > 1 || outputType === "image" || outputType === "both";
  const handleBrandFile = async (file?: File) => {
    if (!file) return;
    try {
      let raw = await file.text();
      if (file.name.toLowerCase().endsWith(".zip")) {
        const { default: JSZip } = await import("jszip");
        const archive = await JSZip.loadAsync(file);
        const manifestName = Object.keys(archive.files).find(name => /(?:_?manifest|brand)\.json$/i.test(name));
        if (!manifestName || archive.files[manifestName].dir) throw new Error("manifest");
        raw = await archive.files[manifestName].async("text");
      }
      const parsed = JSON.parse(raw);
      importBrand.mutate(parsed);
    } catch {
      toast.error(t("invalidBrandFile"));
    }
  };
  const downloadBrandTemplate = () => {
    const template = {
      id: "my-brand",
      name: "My Brand",
      languages: ["es-ES"],
      positioning: { category: "What the brand does", promise: "The useful promise it makes", emotionalTerritory: "How it should feel" },
      verbal: { boilerplate: "Short brand description.", toneAdjectives: ["clear", "credible"], neverSays: [], lexiconUse: [], lexiconAvoid: [] },
      visual: { primaryColor: "#111827", accentColor: "#2563EB", supportingColors: ["#FFFFFF"], gradient: "Describe the gradient or surface direction", typography: "Brand typography", direction: "Describe the visual expression", logoRules: [] },
      editorialRules: ["Do not invent facts, figures or quotes.", "Keep the source and the brand voice distinguishable."],
    };
    const blob = new Blob([JSON.stringify(template, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a"); anchor.href = url; anchor.download = "brand-profile-template.json"; anchor.click(); URL.revokeObjectURL(url);
  };

  if (!articleId) return (
    <div className="px-6 py-8 lg:px-10">
      <div className="mx-auto max-w-3xl text-center py-24">
        <p className="text-muted-foreground">{t("selectSignal")}</p>
        <Button variant="secondary" className="mt-4 rounded-full" onClick={() => navigate("/")}>{t("goDiscover")}</Button>
      </div>
    </div>
  );

  return (
    <div className="px-6 py-8 lg:px-10">
      <div className="mx-auto max-w-5xl">
        {/* Back + header */}
        <button onClick={() => navigate("/")} className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors mb-6">
          <ChevronLeft className="h-4 w-4" />{t("discover")}
        </button>

        {article.isLoading ? (
          <div className="grid gap-8 xl:grid-cols-[1fr_380px] animate-pulse">
            <div className="space-y-6">
              <div className="rounded-xl border border-border bg-card p-6 space-y-3">
                <div className="h-3 w-24 rounded bg-muted" />
                <div className="h-6 w-3/4 rounded bg-muted" />
                <div className="h-4 w-full rounded bg-muted" />
                <div className="h-4 w-2/3 rounded bg-muted" />
              </div>
            </div>
            <div className="rounded-xl border border-border bg-card p-6 space-y-4">
              <div className="h-5 w-32 rounded bg-muted" />
              <div className="h-3 w-48 rounded bg-muted" />
              <div className="flex flex-wrap gap-1.5">{[1,2,3,4,5].map(i => <div key={i} className="h-7 w-20 rounded-md bg-muted" />)}</div>
              <div className="flex flex-wrap gap-1.5">{[1,2,3].map(i => <div key={i} className="h-7 w-16 rounded-md bg-muted" />)}</div>
              <div className="h-11 w-full rounded-full bg-muted" />
            </div>
          </div>
        ) : article.data ? (
          <div className="grid gap-8 xl:grid-cols-[1fr_380px]">
            {/* Left: source + outputs */}
            <div className="space-y-8">
              {/* Source card */}
             <Card className="border-border bg-card">
               <CardContent className="p-6">
                  <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">{t("selectedSignal")}</p>
                  <h2 className="mt-2">{article.data.article.title}</h2>
                  <p className="mt-3 text-muted-foreground leading-relaxed">{article.data.article.summary}</p>
                  <div className="mt-4 flex flex-wrap gap-x-4 text-xs text-muted-foreground font-mono">
                    <span>{article.data.article.source}</span>
                    <span>Score {article.data.article.score}/100</span>
                    <span>{article.data.article.priority}</span>
                  </div>
                </CardContent>
              </Card>

             {/* Live canvas preview */}
             <section className="overflow-hidden rounded-2xl border border-[#635BFF]/25 bg-[#121331] shadow-[0_20px_60px_rgba(18,19,49,0.18)]">
               <div className="flex items-center justify-between border-b border-white/10 px-5 py-3">
                 <div className="flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.16em] text-white/60">
                   <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 shadow-[0_0_0_4px_rgba(52,211,153,0.12)]" />
                   {t("livePreview")}
                 </div>
                 <span className="rounded-full border border-white/10 px-2.5 py-1 text-[10px] text-white/50">{selectedPlatformLabel} · {outputType}</span>
               </div>
               <div className="grid gap-5 p-5 sm:grid-cols-[1fr_180px] sm:items-center">
                 <div>
                   <p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-[#B8B3FF]">{t("canvasPreview")}</p>
                   <h3 className="mt-2 text-xl font-semibold text-white">{article.data.article.title}</h3>
                   <p className="mt-2 text-sm leading-relaxed text-white/60">{t("selectChannelToStart")}. {t("brandDescription")}</p>
                   <div className="mt-4 flex flex-wrap gap-2">
                     <span className="rounded-full bg-white/10 px-2.5 py-1 text-[10px] font-medium text-white/75">{selectedBrandId}</span>
                     <span className="rounded-full bg-white/10 px-2.5 py-1 text-[10px] font-medium text-white/75">{t("visualSystem")}</span>
                   </div>
                 </div>
                 <div className="relative aspect-square overflow-hidden rounded-2xl border border-white/10 bg-gradient-to-br from-[#635BFF] via-[#373083] to-[#0D1028] p-4 shadow-2xl">
                   <div className="absolute -right-8 -top-8 h-24 w-24 rounded-full bg-[#B8B3FF]/30 blur-2xl" />
                   <div className="relative flex h-full flex-col justify-between">
                     <span className="text-[9px] font-semibold uppercase tracking-[0.18em] text-white/70">{selectedPlatformLabel}</span>
                     <div>
                       <div className="mb-2 h-1.5 w-10 rounded-full bg-white/70" />
                       <p className="text-sm font-semibold leading-tight text-white">{t("fromSignalToPiece")}</p>
                     </div>
                   </div>
                 </div>
               </div>
             </section>

             {/* Generated pieces */}
              {pieces.length === 0 && (
                <section className="rounded-xl border border-dashed border-border py-12 text-center">
                  <Sparkles className="mx-auto h-7 w-7 text-muted-foreground/30" />
                  <p className="mt-3 text-sm text-muted-foreground">{t("noPieces")}</p>
                </section>
              )}
              {pieces.length > 0 && (
                <section>
                  <h3 className="text-muted-foreground font-medium mb-4">{t("generatedPieces")}</h3>
                  <div className="space-y-4">
                    {pieces.map(piece => (
                      <Card key={piece.id} className="border-border bg-card overflow-hidden">
                        {piece.imageUrl && (
                          <img src={piece.imageUrl} alt={`${piece.platform} visual`} className="w-full aspect-video object-cover" />
                        )}
                        <CardContent className="p-5">
                          <div className="flex items-center justify-between mb-3">
                            <span className="text-sm font-medium capitalize">{piece.platform} · {piece.variantLabel}</span>
                            <span className="text-[11px] text-muted-foreground font-mono">{piece.dimensions}</span>
                          </div>
                          {piece.textContent && (
                            <p className="whitespace-pre-wrap text-sm text-foreground/80 leading-relaxed max-h-64 overflow-auto">{piece.textContent}</p>
                          )}
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </section>
              )}
            </div>

            {/* Right: generation config */}
            <aside className="space-y-6">
              <Card className="border-primary/20 bg-card sticky top-6">
                <CardContent className="p-6">
                  <h3 className="mb-1">{t("generateContent")}</h3>
                  <p className="text-xs text-muted-foreground mb-6">{t("configureOutput")}</p>

                  {/* Brief editorial */}
                  <div className="mb-5">
                    <button
                      onClick={() => setShowBrief(!showBrief)}
                      className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground hover:text-foreground transition-colors"
                    >
                      <Pencil className="h-3 w-3" />
                      {showBrief ? t("hideBrief") : t("editorialBrief")}
                    </button>
                    {showBrief && (
                      <Textarea
                        value={brief}
                        onChange={e => setBrief(e.target.value)}
                        placeholder={t("briefPlaceholder")}
                        className="mt-2 min-h-20 bg-background border-border text-sm text-foreground placeholder:text-muted-foreground/50 resize-none"
                      />
                    )}
                  </div>

                  {/* Brand Identity */}
                  <div className="mb-5">
                    <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-2">Brand Identity</p>
                    <div className="flex flex-wrap gap-1.5">
                      {(brandProfiles.data || [{ id: "smartball", name: "SMARTBALL" }]).map(brand => (
                        <button
                          key={brand.id}
                          onClick={() => { setConfirmed(false); setSelectedBrandId(brand.id); try { localStorage.setItem("content-engine-active-brand", brand.id); } catch { /* optional */ } }}
                          className={`rounded-md border px-2.5 py-1.5 text-xs transition-all duration-150 ${
                            selectedBrandId === brand.id
                              ? "border-primary bg-primary/10 text-foreground"
                              : "border-border text-muted-foreground hover:border-primary/30"
                          }`}
                        >{brand.name}</button>
                      ))}
                      <input ref={brandFileInput} type="file" accept="application/json,.json,.zip,application/zip" className="hidden" onChange={e => handleBrandFile(e.target.files?.[0])} />
                      <button onClick={() => brandFileInput.current?.click()} disabled={importBrand.isPending} className="inline-flex items-center gap-1.5 rounded-md border border-dashed border-primary/40 px-2.5 py-1.5 text-xs font-medium text-primary hover:bg-primary/5 disabled:opacity-50">
                        <Upload className="h-3.5 w-3.5" />{importBrand.isPending ? t("importing") : t("importBrand")}
                      </button>
                      <button onClick={downloadBrandTemplate} className="inline-flex items-center gap-1.5 rounded-md px-2.5 py-1.5 text-xs text-muted-foreground hover:text-foreground"><Download className="h-3.5 w-3.5" />{t("downloadTemplate")}</button>
                    </div>
                    <p className="mt-2 text-[11px] text-muted-foreground">{t("brandDescription")}</p>
                    <details className="mt-3 rounded-lg border border-border bg-background/50 px-3 py-2">
                      <summary className="cursor-pointer text-[11px] font-medium text-muted-foreground">{t("brandImportHint")}</summary>
                      <p className="mt-2 text-[11px] leading-relaxed text-muted-foreground">{t("identityHowToAdd")}</p>
                    </details>
                  </div>

                  <div className="mb-5">
                    <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-2">{t("generationLanguage")}</p>
                    <div className="grid grid-cols-2 gap-1.5">
                      <button onClick={() => setGenerationLanguage("es")} className={`rounded-md border px-2.5 py-2 text-xs transition-all ${generationLanguage === "es" ? "border-primary bg-primary/10 text-foreground" : "border-border text-muted-foreground hover:border-primary/30"}`}>{t("spanishSpain")}</button>
                      <button onClick={() => setGenerationLanguage("en")} className={`rounded-md border px-2.5 py-2 text-xs transition-all ${generationLanguage === "en" ? "border-primary bg-primary/10 text-foreground" : "border-border text-muted-foreground hover:border-primary/30"}`}>{t("englishUk")}</button>
                    </div>
                  </div>

                  {/* Template */}
                  <div className="mb-5">
                    <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-2">{t("template")}</p>
                    <div className="flex flex-wrap gap-1.5">
                      {templates.map(([id, label]) => (
                        <button
                          key={id}
                          onClick={() => { setConfirmed(false); setContentTemplate(id); }}
                          className={`rounded-md border px-2.5 py-1.5 text-xs transition-all duration-150 ${
                            contentTemplate === id
                              ? "border-primary bg-primary/10 text-foreground"
                              : "border-border text-muted-foreground hover:border-primary/30"
                          }`}
                        >{label}</button>
                      ))}
                    </div>
                  </div>

                  {/* Platforms */}
                  <div className="mb-5">
                    <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-2">Canales ({selectedPlatforms.length})</p>
                    <div className="flex flex-wrap gap-1.5">
                      {platforms.map(([id, label]) => (
                        <button
                          key={id}
                          onClick={() => togglePlatform(id)}
                          className={`rounded-md border px-2.5 py-1.5 text-xs transition-all duration-150 flex items-center gap-1 ${
                            selectedPlatforms.includes(id)
                              ? "border-primary bg-primary/10 text-foreground"
                              : "border-border text-muted-foreground hover:border-primary/30"
                          }`}
                        >
                          {selectedPlatforms.includes(id) && <Check className="h-3 w-3" />}
                          {label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Output type */}
                  <div className="mb-5">
                    <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-2">{t("pieceType")}</p>
                    <div className="grid grid-cols-2 gap-1.5">
                      {([["text", FileText, t("text")], ["image", Image, t("image")], ["video", Video, t("video")], ["both", Sparkles, t("both")]] as const).map(([id, Icon, label]) => (
                        <button
                          key={id}
                          onClick={() => { setConfirmed(false); setOutputType(id); }}
                          className={`flex items-center gap-2 rounded-md border px-3 py-2 text-xs transition-all duration-150 ${
                            outputType === id
                              ? "border-primary bg-primary/10 text-foreground"
                              : "border-border text-muted-foreground hover:border-primary/30"
                          }`}
                        >
                          <Icon className="h-3.5 w-3.5" />{label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Cost confirmation */}
                  {needsConfirm && (
                    <label className="flex items-start gap-2 rounded-lg border border-[var(--chart-3)]/20 bg-[var(--chart-3)]/5 p-3 text-xs text-foreground/80 cursor-pointer mb-4">
                      <input type="checkbox" checked={confirmed} onChange={e => setConfirmed(e.target.checked)} className="mt-0.5 accent-primary" />
                      <span>
                        {selectedPlatforms.length > 1
                          ? `Generar ${selectedPlatforms.length} piezas. `
                          : "Generación visual. "}
                    {t("eachChannel")}{outputType !== "text" ? t("visualAdds") : ""}.
                      </span>
                    </label>
                  )}

                  <Button
                    disabled={!selectedPlatforms.length || generate.isPending || (needsConfirm && !confirmed)}
                    onClick={() => generate.mutate({ articleId, platforms: selectedPlatforms as any, outputType, contentTemplate: contentTemplate as any, brief: brief.trim() || undefined, brandId: selectedBrandId, language: generationLanguage })}
                    className="w-full bg-primary text-primary-foreground hover:opacity-90 rounded-full h-11 font-medium active:scale-[0.97] transition-transform"
                  >
                    {generate.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Sparkles className="mr-2 h-4 w-4" />}
                    {t("generate")} {selectedPlatforms.length} {t("pieces")}
                  </Button>
                </CardContent>
              </Card>
            </aside>
          </div>
        ) : (
          <p className="text-muted-foreground">{t("noSignals")}</p>
        )}
      </div>
    </div>
  );
}
