import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { ChevronRight, FileText, Link2, Loader2, Plus, Radar, Sparkles, Trash2 } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { useLocation } from "wouter";
import { PRODUCT_GUIDE_STEPS, PRODUCT_GUIDE_STORAGE_KEY } from "@shared/productGuide";
import { useLocale } from "@/lib/i18n";

type Mode = "text" | "url" | "scanner";

function ScanSkeleton() {
  return (
    <div className="space-y-2 animate-pulse">
      {[1, 2, 3].map(i => (
        <div key={i} className="rounded-xl border border-border bg-card p-4">
          <div className="flex justify-between">
            <div className="h-4 w-40 rounded bg-muted" />
            <div className="h-3 w-20 rounded bg-muted" />
          </div>
          <div className="mt-2 h-3 w-32 rounded bg-muted" />
        </div>
      ))}
    </div>
  );
}

function ArticleSkeleton() {
  return (
    <div className="space-y-2 animate-pulse">
      {[1, 2, 3, 4].map(i => (
        <div key={i} className="rounded-xl border border-border bg-card p-4">
          <div className="flex items-start gap-3">
            <div className="h-5 w-14 rounded bg-muted shrink-0" />
            <div className="flex-1 space-y-2">
              <div className="h-4 w-3/4 rounded bg-muted" />
              <div className="h-3 w-full rounded bg-muted" />
              <div className="h-3 w-1/2 rounded bg-muted" />
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

function Badge({ value }: { value: string }) {
  const tone = value === "HIGH"
    ? "bg-green-500/10 text-green-400 border-green-500/20"
    : value === "MEDIUM"
    ? "bg-primary/10 text-primary border-primary/20"
    : "bg-muted text-muted-foreground border-border";
  return <span className={`inline-flex items-center rounded-md border px-2 py-0.5 text-[11px] font-medium ${tone}`}>{value}</span>;
}

export default function Discover() {
  const [, navigate] = useLocation();
  const { locale, t } = useLocale();
  const utils = trpc.useUtils();
  const [mode, setMode] = useState<Mode>("scanner");
  const [daysBack, setDaysBack] = useState("3");
  const [text, setText] = useState("");
  const [url, setUrl] = useState("");
  const [selectedScanId, setSelectedScanId] = useState<number | null>(null);
  const [feedName, setFeedName] = useState("");
  const [feedUrl, setFeedUrl] = useState("");
  const [showGuide, setShowGuide] = useState(() => {
    try { return window.localStorage.getItem(PRODUCT_GUIDE_STORAGE_KEY) !== "1"; } catch { return true; }
  });

  const scans = trpc.curator.scans.useQuery();
  const scanDetails = trpc.curator.scanDetails.useQuery({ scanId: selectedScanId! }, { enabled: !!selectedScanId });
  const customFeeds = trpc.curator.listCustomFeeds.useQuery();

  const runScan = trpc.curator.runScan.useMutation({
    onSuccess: data => {
      setSelectedScanId(data.scanId);
      data.totalArticles
        ? toast.success(`${data.totalArticles} ${t("signalsDetected").toLowerCase()}`)
        : toast.warning(t("noSignals"));
      utils.curator.scans.invalidate();
    },
    onError: e => toast.error(e.message),
  });
  const analyzeText = trpc.curator.analyzeText.useMutation({
    onSuccess: data => {
      toast.success(t("signalSaved"));
      navigate(`/create?article=${data.article.id}`);
      utils.curator.scans.invalidate();
    },
    onError: e => toast.error(e.message),
  });
  const importUrl = trpc.curator.importUrl.useMutation({
    onSuccess: data => {
      toast.success(t("sourceImported"));
      navigate(`/create?article=${data.article.id}`);
      utils.curator.scans.invalidate();
    },
    onError: e => toast.error(e.message),
  });
  const addCustomFeed = trpc.curator.addCustomFeed.useMutation({
    onSuccess: () => { setFeedName(""); setFeedUrl(""); toast.success(t("sourceAdded")); utils.curator.listCustomFeeds.invalidate(); },
    onError: e => toast.error(e.message),
  });
  const toggleCustomFeed = trpc.curator.toggleCustomFeed.useMutation({ onSuccess: () => utils.curator.listCustomFeeds.invalidate() });
  const deleteCustomFeed = trpc.curator.deleteCustomFeed.useMutation({ onSuccess: () => { toast.success(t("sourceDeleted")); utils.curator.listCustomFeeds.invalidate(); } });

  const activeArticles = scanDetails.data?.articles || [];
  const pending = runScan.isPending || analyzeText.isPending || importUrl.isPending;
  const textTooShort = text.trim().length > 0 && text.trim().length < 30;
  const urlMalformed = url.trim().length > 0 && !/^https?:\/\/[^\s]+$/i.test(url.trim());

  const handleSource = () => {
    if (mode === "scanner") runScan.mutate({ daysBack: Number(daysBack) });
    else if (mode === "text") { if (!text.trim() || textTooShort) return; analyzeText.mutate({ text }); }
    else { if (!url.trim() || urlMalformed) return; importUrl.mutate({ url }); }
  };

  const dismissGuide = () => {
    setShowGuide(false);
    try { window.localStorage.setItem(PRODUCT_GUIDE_STORAGE_KEY, "1"); } catch { /* storage is optional */ }
  };

  return (
    <div className="px-5 py-7 sm:px-6 lg:px-10 lg:py-9">
      <div className="mx-auto max-w-5xl">
        {/* Header */}
        <header className="mb-8 flex flex-col gap-5 sm:mb-10 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="mb-3 text-[11px] font-semibold uppercase tracking-[0.18em] text-primary">{t("contentEngine")} · {t("productDescriptor")}</p>
            <h1>{t("discoverTitle")}</h1>
            <p className="mt-3 max-w-2xl text-base text-muted-foreground">
              {t("discoverDescription")}
            </p>
          </div>
          <button onClick={() => setShowGuide(true)} className="self-start rounded-full border border-border px-3.5 py-2 text-xs font-medium text-muted-foreground transition-colors hover:border-primary/40 hover:text-foreground sm:self-auto">
            Cómo funciona
          </button>
        </header>

        <section className="mb-8 overflow-hidden rounded-2xl border border-[#8B82FF]/25 bg-[#121331] text-white shadow-[0_20px_60px_rgba(18,19,49,0.25)]">
          <div className="relative p-6 sm:p-8">
            <div className="pointer-events-none absolute -right-20 -top-24 h-64 w-64 rounded-full bg-[#8B82FF]/25 blur-3xl" />
            <div className="relative max-w-3xl">
              <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[#B8B3FF]">CONTENT ENGINE</p>
              <h2 className="mt-2 text-2xl font-semibold tracking-tight text-white sm:text-3xl">{t("valuePropTitle")}</h2>
              <p className="mt-3 max-w-2xl text-sm leading-relaxed text-white/70">{t("valuePropDescription")}</p>
            </div>
            <div className="relative mt-7 grid gap-2 sm:grid-cols-4">
              {[t("valueSource"), t("valueBrand"), t("valueChannels"), t("valueExport")].map((label, index) => (
                <div key={label} className="rounded-xl border border-white/10 bg-white/[0.07] p-3">
                  <span className="font-mono text-[10px] text-[#B8B3FF]">0{index + 1}</span>
                  <p className="mt-2 text-sm font-medium text-white">{label}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {showGuide && (
          <section className="mb-8 overflow-hidden rounded-2xl border border-primary/20 bg-gradient-to-br from-primary/[0.12] via-card to-card shadow-[0_16px_50px_rgba(0,129,251,0.08)]" aria-labelledby="guide-title">
            <div className="flex flex-col gap-6 p-5 sm:p-6 lg:flex-row lg:items-center lg:gap-8">
              <div className="min-w-0 lg:w-[30%]">
                <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-primary">{t("editorialFlow")}</p>
                <h2 id="guide-title" className="mt-2 text-xl sm:text-2xl">{t("fromSignalToPiece")}</h2>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{t("guideDescription")}</p>
              </div>
              <div className="grid flex-1 gap-3 sm:grid-cols-3">
                {PRODUCT_GUIDE_STEPS[locale].map(step => (
                  <div key={step.number} className="rounded-xl border border-border/80 bg-background/45 p-4">
                    <span className="font-mono text-[11px] text-primary">{step.number}</span>
                    <h3 className="mt-3 text-base">{step.title}</h3>
                    <p className="mt-1.5 text-xs leading-relaxed text-muted-foreground">{step.description}</p>
                  </div>
                ))}
              </div>
              <button onClick={dismissGuide} className="self-start text-xs font-medium text-muted-foreground transition-colors hover:text-foreground lg:self-center">{t("understood")}</button>
            </div>
          </section>
        )}

        {/* Source input */}
        <Card className="border-border/80 bg-card/90 shadow-[0_16px_50px_rgba(0,0,0,0.16)]">
          <CardContent className="p-4 sm:p-6 lg:p-7">
            <Tabs value={mode} onValueChange={v => setMode(v as Mode)}>
              <TabsList className="h-10 bg-muted p-1 rounded-lg">
                <TabsTrigger value="text" className="rounded-md data-[state=active]:bg-background data-[state=active]:text-foreground">
                  <FileText className="mr-2 h-3.5 w-3.5" />{t("freeText")}
                </TabsTrigger>
                <TabsTrigger value="url" className="rounded-md data-[state=active]:bg-background data-[state=active]:text-foreground">
                  <Link2 className="mr-2 h-3.5 w-3.5" />{t("urlImport")}
                </TabsTrigger>
                <TabsTrigger value="scanner" className="rounded-md data-[state=active]:bg-background data-[state=active]:text-foreground">
                  <Radar className="mr-2 h-3.5 w-3.5" />{t("scanner")}
                </TabsTrigger>
              </TabsList>
            </Tabs>

            <div className="mt-6">
              {mode === "text" && (
                <div>
                  <Textarea
                    value={text}
                    onChange={e => setText(e.target.value)}
                    placeholder={t("textPlaceholder")}
                    className="min-h-36 bg-background border-border text-foreground placeholder:text-muted-foreground/50 resize-none"
                  />
                  {textTooShort && <p className="mt-2 text-xs text-[var(--chart-3)]">{t("minCharacters")}</p>}
                </div>
              )}
              {mode === "url" && (
                <div>
                  <Input
                    value={url}
                    onChange={e => setUrl(e.target.value)}
                    type="url"
                    placeholder={t("urlPlaceholder")}
                    className="h-12 bg-background border-border text-foreground placeholder:text-muted-foreground/50"
                  />
                  {urlMalformed && <p className="mt-2 text-xs text-[var(--chart-3)]">{t("validUrl")}</p>}
                </div>
              )}
              {mode === "scanner" && (
                <div className="space-y-4">
                  <div className="flex flex-wrap items-center gap-4">
                    <div className="flex-1 min-w-48">
                      <p className="text-sm font-medium">{t("scanRss")}</p>
                      <p className="mt-0.5 text-xs text-muted-foreground">{t("scanRssDescription")}</p>
                    </div>
                    <Select value={daysBack} onValueChange={setDaysBack}>
                      <SelectTrigger className="w-40 h-10 bg-background border-border"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">{t("last24h")}</SelectItem>
                        <SelectItem value="3">{t("last3days")}</SelectItem>
                        <SelectItem value="7">{t("last7days")}</SelectItem>
                        <SelectItem value="14">{t("last14days")}</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Custom feeds */}
                  <details className="rounded-lg border border-border bg-background/50 p-4">
                    <summary className="cursor-pointer text-xs font-medium text-muted-foreground select-none">
                      {t("customFeeds")} ({customFeeds.data?.length || 0})
                    </summary>
                    <div className="mt-4 grid gap-2 sm:grid-cols-[1fr_1.5fr_auto]">
                      <Input value={feedName} onChange={e => setFeedName(e.target.value)} placeholder={t("name")} className="h-9 bg-background border-border text-sm" />
                      <Input value={feedUrl} onChange={e => setFeedUrl(e.target.value)} placeholder="https://medio.com/feed" className="h-9 bg-background border-border text-sm" />
                      <Button
                        disabled={!feedName.trim() || !feedUrl.trim() || addCustomFeed.isPending}
                        onClick={() => addCustomFeed.mutate({ name: feedName, url: feedUrl, category: "Custom" })}
                        variant="secondary"
                        className="h-9"
                      >
                        <Plus className="mr-1 h-3.5 w-3.5" />{t("add")}
                      </Button>
                    </div>
                    <div className="mt-3 space-y-1.5">
                      {customFeeds.data?.map(feed => (
                        <div key={feed.id} className="flex items-center gap-2 rounded-md border border-border bg-background px-3 py-2 text-xs">
                          <button
                            onClick={() => toggleCustomFeed.mutate({ id: feed.id, isActive: !feed.isActive })}
                            className={`h-2 w-2 rounded-full shrink-0 transition-colors ${feed.isActive ? "bg-green-400" : "bg-muted-foreground/30"}`}
                            aria-label="Activar o desactivar"
                          />
                          <span className="truncate flex-1 text-foreground/70">{feed.name}</span>
                          <span className="hidden sm:block truncate max-w-48 text-muted-foreground">{feed.url}</span>
                          <button onClick={() => deleteCustomFeed.mutate({ id: feed.id })} className="p-1 rounded text-muted-foreground hover:text-destructive transition-colors" aria-label="Eliminar">
                            <Trash2 className="h-3 w-3" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </details>
                </div>
              )}
            </div>

            <Button
              onClick={handleSource}
              disabled={pending || (mode === "text" && (!text.trim() || textTooShort)) || (mode === "url" && (!url.trim() || urlMalformed))}
              className="mt-6 bg-primary text-primary-foreground hover:opacity-90 rounded-full h-11 px-6 font-medium active:scale-[0.97] transition-transform"
            >
              {pending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Radar className="mr-2 h-4 w-4" />}
              {mode === "scanner" ? t("scanSources") : mode === "text" ? t("analyzeText") : t("importUrl")}
            </Button>
          </CardContent>
        </Card>

        {/* Scans history */}
        {scans.isLoading ? (
          <section className="mt-10">
            <h3 className="text-muted-foreground font-medium">{t("scansRecent")}</h3>
            <div className="mt-4"><ScanSkeleton /></div>
          </section>
        ) : scans.data && scans.data.length > 0 ? (
          <section className="mt-10">
            <h3 className="text-muted-foreground font-medium">{t("scansRecent")}</h3>
            <div className="mt-4 space-y-2">
              {scans.data.map(scan => (
                <button
                  key={scan.id}
                  onClick={() => setSelectedScanId(scan.id)}
                  className={`w-full text-left rounded-xl border p-4 transition-all duration-150 ${
                    selectedScanId === scan.id
                      ? "border-primary/40 bg-primary/5"
                      : "border-border bg-card hover:border-border hover:bg-accent/50"
                  }`}
                >
                  <div className="flex items-center justify-between gap-4">
                    <span className="text-sm font-medium">
                      Scan #{scan.id} <span className="text-muted-foreground font-normal">· {scan.totalArticles} señales</span>
                    </span>
                    <span className="text-xs text-muted-foreground">{new Date(scan.createdAt).toLocaleDateString("es-ES")}</span>
                  </div>
                  <p className="mt-1 text-xs text-muted-foreground">
                    {scan.highCount} high · {scan.mediumCount} medium · {scan.sourceMode}
                  </p>
                </button>
              ))}
            </div>
          </section>
        ) : null}
        {!scans.isLoading && (!scans.data || scans.data.length === 0) && (
          <section className="mt-10 rounded-xl border border-dashed border-border py-12 text-center">
            <Radar className="mx-auto h-7 w-7 text-muted-foreground/30" />
            <p className="mt-3 text-sm text-muted-foreground">{t("noScans")}</p>
          </section>
        )}

        {/* Articles from selected scan */}
        {selectedScanId && (
          <section className="mt-10">
            <div className="flex items-center justify-between">
              <h3 className="text-muted-foreground font-medium">{t("signalsDetected")}</h3>
            </div>
            <div className="mt-4 space-y-2">
              {scanDetails.isLoading && <ArticleSkeleton />}
              {activeArticles.map(item => (
                <button
                  key={item.id}
                  onClick={() => navigate(`/create?article=${item.id}`)}
                  className="w-full text-left rounded-xl border border-border bg-card p-4 hover:border-primary/30 hover:bg-primary/5 transition-all duration-150 group"
                >
                  <div className="flex items-start gap-3">
                    <Badge value={item.priority} />
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-medium leading-snug">{item.title}</p>
                      <p className="mt-1 line-clamp-2 text-xs text-muted-foreground leading-relaxed">{item.summary}</p>
                      <div className="mt-2 flex flex-wrap gap-x-3 text-[11px] text-muted-foreground font-mono">
                        <span>{item.source}</span>
                        <span>{item.score}/100</span>
                      </div>
                    </div>
                    <ChevronRight className="mt-1 h-4 w-4 shrink-0 text-muted-foreground group-hover:text-primary transition-colors" />
                  </div>
                </button>
              ))}
              {scanDetails.data && !activeArticles.length && (
                <p className="py-8 text-center text-sm text-muted-foreground">{t("noSignals")}</p>
              )}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}
