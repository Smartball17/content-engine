import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Download, Palette, Sparkles, Upload } from "lucide-react";
import { useRef, useState } from "react";
import { toast } from "sonner";
import { useLocation } from "wouter";
import { useLocale } from "@/lib/i18n";

const ACTIVE_BRAND_KEY = "content-engine-active-brand";

export default function BrandStudio() {
  const { t } = useLocale();
  const [, navigate] = useLocation();
  const utils = trpc.useUtils();
  const fileInput = useRef<HTMLInputElement>(null);
  const profiles = trpc.curator.brandProfiles.useQuery();
  const [active, setActive] = useState(() => {
    try { return localStorage.getItem(ACTIVE_BRAND_KEY) || "smartball"; } catch { return "smartball"; }
  });
  const importBrand = trpc.curator.importBrandProfile.useMutation({
    onSuccess: data => {
      setActiveBrand(data.brand.id);
      toast.success(`${data.brand.name} · ${t("brandImported")}`);
      utils.curator.brandProfiles.invalidate();
    },
    onError: e => toast.error(e.message),
  });

  const setActiveBrand = (id: string) => {
    setActive(id);
    try { localStorage.setItem(ACTIVE_BRAND_KEY, id); } catch { /* optional */ }
  };

  const importFile = async (file?: File) => {
    if (!file) return;
    try {
      let raw = await file.text();
      if (file.name.toLowerCase().endsWith(".zip")) {
        const { default: JSZip } = await import("jszip");
        const archive = await JSZip.loadAsync(file);
        const manifestName = Object.keys(archive.files).find(name => /(?:_?manifest|brand)\.json$/i.test(name));
        if (!manifestName || archive.files[manifestName].dir) throw new Error("manifest");
        raw = await archive.files[manifestName].async("text");
      }
      importBrand.mutate(JSON.parse(raw));
    } catch {
      toast.error(t("invalidBrandFile"));
    }
  };

  const downloadTemplate = () => {
    const template = {
      id: "my-brand", name: "My Brand", languages: ["es-ES"],
      positioning: { category: "What the brand does", promise: "The useful promise it makes", emotionalTerritory: "How it should feel" },
      verbal: { boilerplate: "Short brand description.", toneAdjectives: ["clear", "credible"], neverSays: [], lexiconUse: [], lexiconAvoid: [] },
      visual: { primaryColor: "#111827", accentColor: "#2563EB", supportingColors: ["#FFFFFF"], gradient: "Describe the visual direction", typography: "Brand typography", direction: "Describe the visual expression", logoRules: [] },
      editorialRules: ["Do not invent facts, figures or quotes.", "Keep the source and the brand voice distinguishable."],
    };
    const url = URL.createObjectURL(new Blob([JSON.stringify(template, null, 2)], { type: "application/json" }));
    const anchor = document.createElement("a"); anchor.href = url; anchor.download = "brand-profile-template.json"; anchor.click(); URL.revokeObjectURL(url);
  };

  const available = profiles.data || [{ id: "smartball", name: "SMARTBALL" }];

  return (
    <div className="px-6 py-8 lg:px-10">
      <div className="mx-auto max-w-5xl">
        <header className="mb-8 flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="mb-3 text-[11px] font-semibold uppercase tracking-[0.18em] text-primary">{t("contentEngine")} · {t("brandStudio")}</p>
            <h1>{t("brandStudioTitle")}</h1>
            <p className="mt-3 max-w-2xl text-muted-foreground">{t("brandStudioDescription")}</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <input ref={fileInput} type="file" accept="application/json,.json,.zip,application/zip" className="hidden" onChange={e => importFile(e.target.files?.[0])} />
            <Button variant="outline" onClick={() => fileInput.current?.click()} disabled={importBrand.isPending}><Upload className="mr-2 h-4 w-4" />{importBrand.isPending ? t("importing") : t("importBrand")}</Button>
            <Button variant="outline" onClick={downloadTemplate}><Download className="mr-2 h-4 w-4" />{t("downloadTemplate")}</Button>
          </div>
        </header>

        <section className="mb-8 overflow-hidden rounded-2xl border border-[#635BFF]/25 bg-[#121331] text-white shadow-[0_20px_60px_rgba(18,19,49,0.18)]">
          <div className="grid gap-8 p-6 sm:p-8 lg:grid-cols-[1fr_280px] lg:items-center">
            <div>
              <div className="flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.18em] text-[#B8B3FF]"><Palette className="h-3.5 w-3.5" />{t("activeBrand")}</div>
              <h2 className="mt-3 text-3xl font-semibold text-white">{available.find(brand => brand.id === active)?.name || active}</h2>
              <p className="mt-3 max-w-xl text-sm leading-relaxed text-white/65">{t("activeBrandDescription")}</p>
              <Button className="mt-6 rounded-full bg-white text-[#121331] hover:bg-white/90" onClick={() => navigate(`/create?brand=${encodeURIComponent(active)}`)}><Sparkles className="mr-2 h-4 w-4" />{t("useInCreate")}</Button>
            </div>
            <div className="relative aspect-square max-w-[220px] overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-br from-[#635BFF] via-[#373083] to-[#0D1028] p-5 shadow-2xl lg:justify-self-end">
              <div className="absolute -right-10 -top-10 h-32 w-32 rounded-full bg-[#B8B3FF]/30 blur-3xl" />
              <div className="relative flex h-full flex-col justify-between"><span className="text-[10px] font-semibold uppercase tracking-[0.18em] text-white/65">{t("brandIdentity")}</span><span className="text-xl font-semibold text-white">{available.find(brand => brand.id === active)?.name || active}</span></div>
            </div>
          </div>
        </section>

        <div className="mb-3 flex items-end justify-between"><div><h2 className="text-xl">{t("yourBrandIdentities")}</h2><p className="mt-1 text-sm text-muted-foreground">{t("brandStudioChoose")}</p></div><span className="text-xs text-muted-foreground">{available.length} {t("identities")}</span></div>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {available.map(brand => (
            <button key={brand.id} onClick={() => setActiveBrand(brand.id)} className={`group rounded-2xl border p-5 text-left transition-all hover:-translate-y-0.5 hover:shadow-lg ${active === brand.id ? "border-primary bg-primary/[0.07] shadow-md shadow-primary/10" : "border-border bg-card hover:border-primary/35"}`}>
              <div className="flex items-start justify-between"><span className={`grid h-10 w-10 place-items-center rounded-xl ${active === brand.id ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}><Palette className="h-4 w-4" /></span>{active === brand.id && <span className="rounded-full bg-primary/10 px-2 py-1 text-[10px] font-semibold uppercase tracking-wider text-primary">{t("active")}</span>}</div>
              <h3 className="mt-5 text-lg">{brand.name}</h3><p className="mt-1 text-xs text-muted-foreground">{brand.id}</p><p className="mt-4 text-sm text-muted-foreground">{t("brandCardDescription")}</p>
            </button>
          ))}
        </div>

        <section className="mt-8 rounded-2xl border border-border bg-card p-5 sm:p-6"><h2 className="text-lg">{t("howBrandWorks")}</h2><div className="mt-4 grid gap-3 sm:grid-cols-3">{[t("brandStepOne"), t("brandStepTwo"), t("brandStepThree")].map((step, index) => <div key={step} className="rounded-xl bg-muted/60 p-4"><span className="font-mono text-xs text-primary">0{index + 1}</span><p className="mt-2 text-sm leading-relaxed">{step}</p></div>)}</div></section>
      </div>
    </div>
  );
}
