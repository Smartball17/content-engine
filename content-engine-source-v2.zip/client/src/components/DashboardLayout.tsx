import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Sidebar, SidebarContent, SidebarFooter, SidebarHeader, SidebarInset, SidebarMenu, SidebarMenuButton, SidebarMenuItem, SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { BookOpen, LogOut, Palette, Radar, Sparkles } from "lucide-react";
import { useLocation } from "wouter";
import { useLocale } from "@/lib/i18n";
import { useTheme } from "@/contexts/ThemeContext";

const menu = [
  { icon: Radar, label: "discover", path: "/" },
  { icon: Sparkles, label: "create", path: "/create" },
  { icon: Palette, label: "brandStudio", path: "/brands" },
  { icon: BookOpen, label: "library", path: "/library" },
] as const;

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const { loading, user, logout } = useAuth();
  const [location, setLocation] = useLocation();
  const { locale, setLocale, t } = useLocale();
  const { theme, toggleTheme } = useTheme();

  if (loading) return <div className="min-h-screen bg-background" />;

  if (!user) return (
    <div className="min-h-screen bg-background text-foreground flex items-center justify-center px-6">
      <div className="max-w-sm text-center">
        <h1 className="text-2xl font-semibold tracking-tight">{t("contentEngine")}</h1>
        <p className="mt-3 text-muted-foreground">
          {t("signInDescription")}
        </p>
        <Button
          className="mt-8 bg-primary text-primary-foreground hover:opacity-90 rounded-full px-8 h-11 font-medium"
          onClick={() => startLogin()}
        >
          {t("signIn")}
        </Button>
      </div>
    </div>
  );

  return (
    <SidebarProvider defaultOpen>
      <Sidebar className="border-r border-border bg-sidebar text-sidebar-foreground">
        <SidebarHeader className="h-24 px-4 justify-center">
          <div className="flex items-center gap-3">
            <img src="/product-mark.svg" alt="Content Engine" className="h-10 w-10 shrink-0" />
            <div className="min-w-0">
              <span className="block text-[15px] font-semibold tracking-tight">Content Engine</span>
              <span className="block text-[10px] font-medium uppercase tracking-[0.12em] text-sidebar-foreground/45">{t("productDescriptor")}</span>
            </div>
          </div>
        </SidebarHeader>

        <SidebarContent>
          <SidebarMenu className="px-3 py-2">
            {menu.map(item => (
              <SidebarMenuItem key={item.path}>
                <SidebarMenuButton
                  isActive={location === item.path}
                  onClick={() => setLocation(item.path)}
                  tooltip={t(item.label)}
                  className="h-10 rounded-lg text-sidebar-foreground/65 hover:text-sidebar-foreground hover:bg-sidebar-accent data-[active=true]:bg-sidebar-primary/20 data-[active=true]:text-sidebar-foreground"
                >
                  <item.icon className="h-4 w-4" />
                  <span className="font-medium">{t(item.label)}</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
            ))}
          </SidebarMenu>
        </SidebarContent>

        <SidebarFooter className="border-t border-border p-3">
          <div className="mb-3 flex items-center justify-between gap-2 rounded-lg border border-sidebar-border bg-sidebar-accent/40 p-2">
            <span className="text-[10px] font-semibold uppercase tracking-[0.16em] text-sidebar-foreground/55">{t("language")}</span>
            <div className="flex rounded-md bg-sidebar-accent p-0.5 text-[10px] font-medium">
              {(["es", "en"] as const).map(option => (
                <button key={option} onClick={() => setLocale(option)} className={`rounded px-2 py-1 uppercase transition-colors ${locale === option ? "bg-sidebar-primary text-white" : "text-sidebar-foreground/60 hover:text-sidebar-foreground"}`} aria-pressed={locale === option}>{option}</button>
              ))}
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Avatar className="h-7 w-7">
              <AvatarFallback className="bg-primary/10 text-primary text-xs font-medium">
                {user.name?.slice(0, 1).toUpperCase() || "S"}
              </AvatarFallback>
            </Avatar>
            <div className="min-w-0 flex-1">
              <p className="text-xs font-medium truncate">{user.name || "Usuario"}</p>
            </div>
            <button
              onClick={logout}
              className="p-2 rounded-md text-muted-foreground hover:text-foreground hover:bg-accent transition-colors"
              aria-label="Cerrar sesión"
            >
              <LogOut className="h-3.5 w-3.5" />
            </button>
          </div>
          {toggleTheme && (
            <button onClick={toggleTheme} className="mt-2 w-full rounded-md px-2 py-1.5 text-left text-[11px] text-sidebar-foreground/55 transition-colors hover:bg-sidebar-accent hover:text-sidebar-foreground">
              {theme === "light" ? "Dark mode" : "Light mode"}
            </button>
          )}
        </SidebarFooter>
      </Sidebar>

      <SidebarInset className="bg-background text-foreground">
        <div className="md:hidden h-14 flex items-center border-b border-border bg-sidebar/95 px-4">
          <SidebarTrigger />
          <img src="/product-mark.svg" alt="" className="ml-3 h-7 w-7" />
          <span className="ml-2 text-sm font-semibold">Content Engine</span>
        </div>
        <main className="min-h-screen">
          {children}
        </main>
      </SidebarInset>
    </SidebarProvider>
  );
}
