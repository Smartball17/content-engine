import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import DashboardLayout from "@/components/DashboardLayout";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Discover from "./pages/Discover";
import Create from "./pages/Create";
import Library from "./pages/Library";
import BrandStudio from "./pages/BrandStudio";
import NotFound from "./pages/NotFound";
import { LocaleProvider } from "./lib/i18n";
import { Route, Switch } from "wouter";

function Router() {
  return (
    <DashboardLayout>
      <Switch>
        <Route path="/" component={Discover} />
        <Route path="/create" component={Create} />
        <Route path="/library" component={Library} />
        <Route path="/brands" component={BrandStudio} />
        <Route path="/404" component={NotFound} />
        <Route component={NotFound} />
      </Switch>
    </DashboardLayout>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light" switchable>
        <LocaleProvider>
          <TooltipProvider>
            <Toaster />
            <Router />
          </TooltipProvider>
        </LocaleProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}
