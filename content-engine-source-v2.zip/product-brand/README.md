# Content Engine — identidad de producto

## Decisión de trabajo

**Content Engine** es el nombre de producto elegido para esta versión porque explica inmediatamente la categoría y no confunde la herramienta con SMARTBALL, que es una identidad aplicable al contenido.

**Content Magic** se descarta como nombre principal porque promete un resultado mágico y menos controlable; puede funcionar como campaña o tagline, no como producto.

## Concepto del logotipo

El símbolo combina:

- una trayectoria ascendente: la señal encontrada se convierte en una pieza útil;
- un punto de partida: descubrimiento e investigación;
- una chispa: IA y creatividad editorial;
- una forma cuadrada redondeada: herramienta de trabajo, no logo decorativo.

La paleta violeta-azul pertenece al producto. SMARTBALL conserva sus colores cuando se selecciona como Brand Identity para generar piezas.

## Límite

El nombre es una decisión creativa de producto, no una comprobación de disponibilidad legal, dominio o marca registrada.
