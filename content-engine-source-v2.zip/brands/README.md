# Brand profiles

Los perfiles siguen el contrato `brand-identity-builder` v2: `brand.json` es la fuente editable y `_MANIFEST.json` debe ser generado por el Skill cuando se incorpore un paquete completo de marca.

El runtime del Content Engine usa `server/brandProfiles.ts` como proyección ligera y segura del perfil: no carga archivos locales arbitrarios ni depende de Google Drive en cada generación.

Para añadir una marca:

1. Crear o mantener la identidad con `brand-identity-builder`.
2. Verificar manifest, tokens, guía, assets y aprobación.
3. Mapear el perfil aprobado a `BrandProfile`.
4. Añadirlo a `PROFILES` y cubrirlo con tests.
5. Solo después habilitarlo en la interfaz.

La exportación de la identidad y sus assets no se activa automáticamente desde el Content Engine.
