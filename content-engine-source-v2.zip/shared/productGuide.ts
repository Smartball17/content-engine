export const PRODUCT_GUIDE_STORAGE_KEY = "smartball-content-engine:guide-dismissed:v1";

export const PRODUCT_GUIDE_STEPS = {
  es: [
    { number: "01", title: "Detecta", description: "Escanea fuentes RSS, pega una URL o introduce una idea propia." },
    { number: "02", title: "Crea", description: "Elige canal, formato, plantilla y Brand Identity para adaptar la señal." },
    { number: "03", title: "Guarda", description: "Revisa las piezas generadas y consérvalas en tu Library editorial." },
  ],
  en: [
    { number: "01", title: "Discover", description: "Scan RSS sources, paste a URL or add your own idea." },
    { number: "02", title: "Create", description: "Choose a channel, format, template and Brand Identity to adapt the signal." },
    { number: "03", title: "Save", description: "Review generated pieces and keep them in your editorial Library." },
  ],
} as const;
