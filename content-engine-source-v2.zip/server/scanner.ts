import Parser from "rss-parser";

export const RSS_FEEDS = [
  { url: "https://venturebeat.com/category/ai/feed/", name: "VentureBeat AI" },
  { url: "https://www.wired.com/feed/tag/ai/latest/rss", name: "Wired AI" },
  { url: "https://feeds.arstechnica.com/arstechnica/index", name: "Ars Technica" },
  { url: "https://techcrunch.com/category/artificial-intelligence/feed/", name: "TechCrunch AI" },
  { url: "https://www.technologyreview.com/feed/", name: "MIT Technology Review" },
  { url: "https://www.theverge.com/rss/ai-artificial-intelligence/index.xml", name: "The Verge AI" },
  { url: "https://analyticsindiamag.com/feed/", name: "Analytics India" },
  { url: "https://www.artificialintelligence-news.com/feed/rss/", name: "AI News" },
  { url: "https://siliconangle.com/category/ai/feed", name: "SiliconANGLE AI" },
  { url: "https://futurism.com/categories/ai-artificial-intelligence/feed", name: "Futurism AI" },
] as const;

const TREND_KEYWORDS = ["gpt-5", "gpt-4", "sora", "gemini", "claude", "llama", "openai", "anthropic", "google", "meta", "apple", "nvidia", "agent", "multimodal", "reasoning", "ai", "inteligencia artificial"];
const PRACTICAL_KEYWORDS = ["how to", "guide", "tutorial", "prompt", "automation", "marketing", "sales", "content", "productivity", "workflow", "business", "enterprise", "startup", "use case", "estrategia", "empresa"];
const VIRAL_KEYWORDS = ["breakthrough", "launch", "new", "billion", "million", "lawsuit", "regulation", "risk", "race", "future", "jobs", "record"];

export type Priority = "HIGH" | "MEDIUM" | "LOW" | "SKIP";

export type ScannedArticle = {
  title: string;
  source: string;
  url: string;
  summary: string;
  publishedDate: string;
  score: number;
  priority: Priority;
  scoringReasons: string;
  adaptationAngle: string;
};

export type ScanResult = {
  articles: ScannedArticle[];
  totalArticles: number;
  highCount: number;
  mediumCount: number;
  lowCount: number;
  skipCount: number;
};

type FeedSource = { url: string; name: string };

const cleanHtml = (value: string) => value.replace(/<[^>]*>/g, " ").replace(/&[a-z#0-9]+;/gi, " ").replace(/\s+/g, " ").trim();

export function scoreArticle(title: string, summary: string, publishedDate: string) {
  const text = `${title} ${summary}`.toLowerCase();
  const reasons: string[] = [];
  let score = 0;
  const age = Math.floor((Date.now() - new Date(publishedDate).getTime()) / 86_400_000);
  if (Number.isFinite(age) && age <= 0) { score += 25; reasons.push("Actualidad (+25)"); }
  else if (age === 1) { score += 20; reasons.push("Ayer (+20)"); }
  else if (age <= 3) { score += 15; reasons.push("Reciente (+15)"); }
  else if (age <= 7) { score += 5; reasons.push("Semana (+5)"); }

  const trendCount = TREND_KEYWORDS.filter(keyword => text.includes(keyword)).length;
  if (trendCount >= 3) { score += 25; reasons.push("Tendencia alta (+25)"); }
  else if (trendCount === 2) { score += 20; reasons.push("Tendencia (+20)"); }
  else if (trendCount === 1) { score += 10; reasons.push("Señal de tendencia (+10)"); }

  const practicalCount = PRACTICAL_KEYWORDS.filter(keyword => text.includes(keyword)).length;
  if (practicalCount >= 2) { score += 25; reasons.push("Aplicable (+25)"); }
  else if (practicalCount === 1) { score += 15; reasons.push("Aplicación posible (+15)"); }

  const viralCount = VIRAL_KEYWORDS.filter(keyword => text.includes(keyword)).length;
  if (viralCount >= 2) { score += 25; reasons.push("Alto interés (+25)"); }
  else if (viralCount === 1) { score += 15; reasons.push("Interés potencial (+15)"); }

  const priority: Priority = score >= 75 ? "HIGH" : score >= 50 ? "MEDIUM" : score >= 25 ? "LOW" : "SKIP";
  return { score, priority, reasons: reasons.join(" · ") || "Señal sin coincidencias de scoring" };
}

export async function scanFeeds(daysBack: number, extraFeeds: FeedSource[] = []): Promise<ScanResult> {
  const parser = new Parser({ timeout: 12_000, headers: { "User-Agent": "SMARTBALL-Content-Engine/1.0" } });
  const cutoff = new Date(Date.now() - daysBack * 86_400_000);
  const seen = new Set<string>();
  const articles: ScannedArticle[] = [];

  await Promise.allSettled([...RSS_FEEDS, ...extraFeeds].map(async feed => {
    try {
      const parsed = await parser.parseURL(feed.url);
      for (const item of parsed.items) {
        const publishedDate = item.isoDate || item.pubDate || new Date().toISOString();
        if (new Date(publishedDate) < cutoff) continue;
        const url = item.link || "";
        const title = cleanHtml(item.title || "");
        if (!title || (url && seen.has(url))) continue;
        if (url) seen.add(url);
        const summary = cleanHtml(item.contentSnippet || item.content || "").slice(0, 800);
        const scored = scoreArticle(title, summary, publishedDate);
        articles.push({
          title,
          source: parsed.title || feed.name,
          url: url || feed.url,
          summary,
          publishedDate: new Date(publishedDate).toISOString().slice(0, 10),
          score: scored.score,
          priority: scored.priority,
          scoringReasons: scored.reasons,
          adaptationAngle: scored.priority === "HIGH" ? "Convertir la noticia en una lectura estratégica para la audiencia SMARTBALL." : "Explicar el hecho y extraer una implicación práctica.",
        });
      }
    } catch (error) {
      console.warn(`[Scanner] Feed no disponible: ${feed.name}`, error instanceof Error ? error.message : error);
    }
  }));

  articles.sort((a, b) => b.score - a.score);
  return {
    articles,
    totalArticles: articles.length,
    highCount: articles.filter(item => item.priority === "HIGH").length,
    mediumCount: articles.filter(item => item.priority === "MEDIUM").length,
    lowCount: articles.filter(item => item.priority === "LOW").length,
    skipCount: articles.filter(item => item.priority === "SKIP").length,
  };
}

function assertPublicUrl(input: string) {
  const url = new URL(input);
  const host = url.hostname.toLowerCase();
  if (!/^https?:$/.test(url.protocol) || host === "localhost" || host === "0.0.0.0" || host === "[::1]" || host.endsWith(".local") || /^127\.|^10\.|^169\.254\.|^192\.168\.|^172\.(1[6-9]|2\d|3[0-1])\./.test(host)) {
    throw new Error("La URL debe ser pública y usar HTTP o HTTPS.");
  }
  return url;
}

export async function importArticleUrl(input: string): Promise<ScannedArticle> {
  const url = assertPublicUrl(input);
  const response = await fetch(url, { headers: { "User-Agent": "SMARTBALL-Content-Engine/1.0" }, signal: AbortSignal.timeout(12_000), redirect: "error" });
  if (!response.ok) throw new Error(`No se pudo importar la URL (${response.status}).`);
  const html = (await response.text()).slice(0, 1_000_000);
  const title = cleanHtml(html.match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1] || url.hostname);
  const meta = html.match(/<meta[^>]+(?:name=["']description["']|property=["']og:description["'])[^>]+content=["']([^"']+)["']/i)?.[1];
  const body = cleanHtml(html.replace(/<script[\s\S]*?<\/script>|<style[\s\S]*?<\/style>/gi, " "));
  const summary = cleanHtml(meta || body).slice(0, 800);
  const scored = scoreArticle(title, summary, new Date().toISOString());
  return { title, source: url.hostname.replace(/^www\./, ""), url: url.toString(), summary, publishedDate: new Date().toISOString().slice(0, 10), score: scored.score, priority: scored.priority, scoringReasons: scored.reasons, adaptationAngle: "Extraer la perspectiva SMARTBALL y la implicación estratégica de la fuente." };
}

export function createTextArticle(input: string): ScannedArticle {
  const cleaned = input.trim().replace(/\s+/g, " ");
  const title = cleaned.split(/[.!?]/)[0]?.slice(0, 120) || "Idea de contenido";
  const scored = scoreArticle(title, cleaned, new Date().toISOString());
  return { title, source: "Entrada manual", url: "https://smartball.manus.space", summary: cleaned.slice(0, 800), publishedDate: new Date().toISOString().slice(0, 10), score: Math.max(scored.score, 50), priority: scored.score >= 50 ? scored.priority : "MEDIUM", scoringReasons: `${scored.reasons} · Fuente propia`, adaptationAngle: "Convertir la idea en una perspectiva de negocio clara, útil y alineada con SMARTBALL." };
}
