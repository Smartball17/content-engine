import { COOKIE_NAME } from "@shared/const";
import { z } from "zod";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { addCustomFeed, createFeedScan, deleteCustomFeed, getArticlesByScan, getOwnedArticle, getOwnedScan, insertArticles, listCustomFeeds, listOwnedBrandProfiles, listPieces, listScans, markAdapted, saveBrandProfile, savePiece, toggleCustomFeed, toggleFavorite, updateFeedScan } from "./db";
import { CONTENT_TEMPLATES, generatePiece, getVariants, PLATFORMS, type ContentTemplate, type OutputType, type Platform } from "./contentGenerator";
import { createTextArticle, importArticleUrl, RSS_FEEDS, scanFeeds, type ScannedArticle } from "./scanner";
import { getBrandProfile, listBrandProfiles, normalizeImportedBrandProfile, parseBrandProfile } from "./brandProfiles";

const platformEnum = z.enum(PLATFORMS);
const outputEnum = z.enum(["text", "image", "video", "both"]);
const brandProfileInput = z.record(z.string(), z.unknown());

async function saveSource(ownerId: number, mode: "scanner" | "text" | "url", items: ScannedArticle[], daysBack = 1) {
  const scanId = await createFeedScan({ ownerId, daysBack, sourceMode: mode, status: "running" });
  try {
    await insertArticles(items.map(item => ({ scanId, title: item.title, source: item.source, url: item.url, summary: item.summary, publishedDate: item.publishedDate, score: item.score, priority: item.priority, scoringReasons: item.scoringReasons, adaptationAngle: item.adaptationAngle })));
    const totalArticles = items.length;
    await updateFeedScan(scanId, { status: "completed", totalArticles, highCount: items.filter(item => item.priority === "HIGH").length, mediumCount: items.filter(item => item.priority === "MEDIUM").length, lowCount: items.filter(item => item.priority === "LOW").length, skipCount: items.filter(item => item.priority === "SKIP").length });
    return { scanId, totalArticles };
  } catch (error) {
    await updateFeedScan(scanId, { status: "failed" });
    throw error;
  }
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => { ctx.res.clearCookie(COOKIE_NAME, { ...getSessionCookieOptions(ctx.req), maxAge: -1 }); return { success: true } as const; }),
  }),
  curator: router({
    defaultSources: protectedProcedure.query(() => RSS_FEEDS),
    listCustomFeeds: protectedProcedure.query(({ ctx }) => listCustomFeeds(ctx.user.id)),
    addCustomFeed: protectedProcedure.input(z.object({ name: z.string().trim().min(2).max(255), url: z.string().url(), category: z.string().trim().min(2).max(128).default("Custom") })).mutation(async ({ ctx, input }) => ({ id: await addCustomFeed(ctx.user.id, input.name, input.url, input.category) })),
    toggleCustomFeed: protectedProcedure.input(z.object({ id: z.number(), isActive: z.boolean() })).mutation(({ ctx, input }) => toggleCustomFeed(input.id, ctx.user.id, input.isActive)),
    deleteCustomFeed: protectedProcedure.input(z.object({ id: z.number() })).mutation(({ ctx, input }) => deleteCustomFeed(input.id, ctx.user.id)),
    variants: protectedProcedure.query(() => getVariants()),
    contentTemplates: protectedProcedure.query(() => CONTENT_TEMPLATES),
    brandProfiles: protectedProcedure.query(async ({ ctx }) => {
      const rows = await listOwnedBrandProfiles(ctx.user.id);
      const extras = rows.flatMap(row => { try { return [parseBrandProfile(row.profileJson)]; } catch { return []; } });
      return listBrandProfiles(extras);
    }),
    importBrandProfile: protectedProcedure.input(brandProfileInput).mutation(async ({ ctx, input }) => {
      const profile = normalizeImportedBrandProfile(input);
      const id = await saveBrandProfile({ ownerId: ctx.user.id, brandId: profile.id, name: profile.name, profileJson: JSON.stringify(profile) });
      return { id, brand: { id: profile.id, name: profile.name } };
    }),
    runScan: protectedProcedure.input(z.object({ daysBack: z.number().int().min(1).max(14).default(3) })).mutation(async ({ ctx, input }) => {
      const custom = await listCustomFeeds(ctx.user.id, true);
      const result = await scanFeeds(input.daysBack, custom.map(item => ({ name: item.name, url: item.url })));
      const saved = await saveSource(ctx.user.id, "scanner", result.articles, input.daysBack);
      return { ...saved, ...result };
    }),
    analyzeText: protectedProcedure.input(z.object({ text: z.string().trim().min(30).max(20_000) })).mutation(async ({ ctx, input }) => {
      const item = createTextArticle(input.text);
      const saved = await saveSource(ctx.user.id, "text", [item]);
      return { ...saved, article: (await getArticlesByScan(saved.scanId))[0] };
    }),
    importUrl: protectedProcedure.input(z.object({ url: z.string().url() })).mutation(async ({ ctx, input }) => {
      const item = await importArticleUrl(input.url);
      const saved = await saveSource(ctx.user.id, "url", [item]);
      return { ...saved, article: (await getArticlesByScan(saved.scanId))[0] };
    }),
    scans: protectedProcedure.query(({ ctx }) => listScans(ctx.user.id)),
    scanDetails: protectedProcedure.input(z.object({ scanId: z.number() })).query(async ({ ctx, input }) => {
      const scan = await getOwnedScan(input.scanId, ctx.user.id); if (!scan) throw new Error("Escaneo no encontrado.");
      return { scan, articles: await getArticlesByScan(scan.id) };
    }),
    article: protectedProcedure.input(z.object({ articleId: z.number() })).query(async ({ ctx, input }) => {
      const article = await getOwnedArticle(input.articleId, ctx.user.id); if (!article) throw new Error("Artículo no encontrado.");
      return { article, pieces: await listPieces(ctx.user.id, article.id) };
    }),
    generate: protectedProcedure.input(z.object({ articleId: z.number(), platforms: z.array(platformEnum).min(1).max(8), outputType: outputEnum, contentTemplate: z.enum(CONTENT_TEMPLATES).default("no_template"), brief: z.string().max(1000).optional(), brandId: z.string().trim().min(1).max(64).default("smartball"), language: z.enum(["es", "en"]).default("es") })).mutation(async ({ ctx, input }) => {
      const article = await getOwnedArticle(input.articleId, ctx.user.id); if (!article) throw new Error("Artículo no encontrado.");
      const profileRows = await listOwnedBrandProfiles(ctx.user.id);
      const profiles = profileRows.flatMap(row => { try { return [parseBrandProfile(row.profileJson)]; } catch { return []; } });
      const brand = getBrandProfile(input.brandId, profiles);
      const results = [];
      for (const platform of input.platforms) {
        const generated = await generatePiece({ title: article.title, summary: article.summary || "", source: article.source, url: article.url, adaptationAngle: article.adaptationAngle }, platform as Platform, input.outputType as OutputType, input.contentTemplate as ContentTemplate, input.brief, brand, input.language);
        const id = await savePiece({ articleId: article.id, brandId: brand.id, platform, variantId: generated.id, variantLabel: generated.label, contentTemplate: input.contentTemplate, outputType: input.outputType, textContent: generated.textContent, imageUrl: generated.imageUrl, format: generated.format, dimensions: generated.dimensions });
        results.push({ contentId: id, platform, ...generated, outputType: input.outputType });
      }
      await markAdapted(article.id);
      return { articleId: article.id, totalPieces: results.length, results };
    }),
    library: protectedProcedure.input(z.object({ articleId: z.number().optional() }).optional()).query(({ ctx, input }) => listPieces(ctx.user.id, input?.articleId)),
    toggleFavorite: protectedProcedure.input(z.object({ id: z.number() })).mutation(({ ctx, input }) => toggleFavorite(input.id, ctx.user.id)),
  }),
});

export type AppRouter = typeof appRouter;
