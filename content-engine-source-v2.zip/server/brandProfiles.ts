export type BrandProfile = {
  id: string;
  name: string;
  legalEntity?: string;
  languages: string[];
  positioning: {
    category: string;
    promise: string;
    emotionalTerritory: string;
  };
  verbal: {
    boilerplate: string;
    toneAdjectives: string[];
    neverSays: string[];
    lexiconUse: string[];
    lexiconAvoid: string[];
  };
  visual: {
    primaryColor: string;
    accentColor: string;
    supportingColors: string[];
    gradient: string;
    typography: string;
    direction: string;
    logoRules: string[];
  };
  editorialRules: string[];
};

/**
 * Perfil normalizado según el contrato de brand-identity-builder v2.
 * Los assets pesados y el manifest completo viven fuera del runtime; aquí solo
 * se conserva el contexto necesario para generar y validar contenido.
 */
export const SMARTBALL_BRAND: BrandProfile = {
  id: "smartball",
  name: "SMARTBALL",
  legalEntity: "Sociedad patrimonial y plataforma de consultoría, asesoría y consejos de administración",
  languages: ["es-ES"],
  positioning: {
    category: "Sociedad patrimonial y consultoría estratégica",
    promise: "Convertir señales complejas en criterio útil para decisiones de negocio y gobierno.",
    emotionalTerritory: "Solidez, inteligencia, rigor y dinamismo tecnológico.",
  },
  verbal: {
    boilerplate: "SMARTBALL es una sociedad patrimonial y plataforma de consultoría, asesoría y consejos de administración.",
    toneAdjectives: ["sobrio", "preciso", "estratégico", "comercial"],
    neverSays: ["revolucionario", "disruptivo", "la mejor", "garantizado", "sin precedentes"],
    lexiconUse: ["criterio", "implicación", "decisión", "gobierno", "evidencia", "estrategia"],
    lexiconAvoid: ["hype", "promesas absolutas", "superlativos sin evidencia", "jerga vacía"],
  },
  visual: {
    primaryColor: "#0D1B3E",
    accentColor: "#0081FB",
    supportingColors: ["#4A4A4A", "#8C8C8C", "#F5F7FA", "#FFFFFF"],
    gradient: "45deg from #0D1B3E to #0081FB",
    typography: "Noto Sans; fallback Helvetica Neue or Arial",
    direction: "Sofisticada, financiera-corporativa y tecnológica; creíble, contenida y sin neón.",
    logoRules: ["No deformar, rotar, recolorear ni añadir sombras al logotipo.", "Usar áreas despejadas y contraste suficiente.", "Respetar el gradiente corporativo y la jerarquía bicolor."],
  },
  editorialRules: [
    "Escribir en español de España salvo que el usuario indique otro idioma.",
    "La fuente es el protagonista: explicar qué ha ocurrido y por qué importa antes de añadir la lectura de marca.",
    "Atribuir la fuente al final cuando exista.",
    "No inventar cifras, citas, resultados ni credenciales.",
    "Preparar una pieza lista para revisión editorial, no una nota técnica del proceso.",
  ],
};

const PROFILES: Record<string, BrandProfile> = { smartball: SMARTBALL_BRAND };

export function parseBrandProfile(profileJson: string): BrandProfile {
  const profile = JSON.parse(profileJson) as BrandProfile;
  if (!profile.id || !profile.name || !profile.positioning || !profile.verbal || !profile.visual || !profile.editorialRules) {
    throw new Error("El Brand Profile no tiene la estructura mínima requerida.");
  }
  return profile;
}

export function normalizeImportedBrandProfile(input: unknown): BrandProfile {
  const value = input as Record<string, any>;
  if (value.id && value.name && value.positioning && value.verbal && value.visual) {
    return parseBrandProfile(JSON.stringify(value));
  }
  const manifestBrand = value.brand || {};
  const positioning = value.positioning || {};
  const verbal = value.verbal || {};
  const visual = value.visual || value.brand?.visual || {};
  const logo = value.logo || {};
  const profile: BrandProfile = {
    id: String(value.id || manifestBrand.slug || "brand").toLowerCase().replace(/[^a-z0-9-]+/g, "-").replace(/^-|-$/g, "").slice(0, 64),
    name: String(value.name || manifestBrand.name || "Imported brand"),
    legalEntity: value.legalEntity || manifestBrand.legal_entity,
    languages: value.languages || ["es-ES"],
    positioning: {
      category: String(positioning.category || "Brand content"),
      promise: String(positioning.promise || "Convert relevant signals into useful content."),
      emotionalTerritory: String(positioning.emotionalTerritory || positioning.emotional_territory || "Credible and coherent."),
    },
    verbal: {
      boilerplate: String(verbal.boilerplate || `${manifestBrand.name || "The brand"} creates useful, coherent content.`),
      toneAdjectives: verbal.toneAdjectives || verbal.tone_adjectives || ["clear", "credible", "useful"],
      neverSays: verbal.neverSays || verbal.never_says || [],
      lexiconUse: verbal.lexiconUse || verbal.lexicon_use || [],
      lexiconAvoid: verbal.lexiconAvoid || verbal.lexicon_avoid || [],
    },
    visual: {
      primaryColor: String(visual.primaryColor || visual.primary_color || "#111827"),
      accentColor: String(visual.accentColor || visual.accent_color || "#2563EB"),
      supportingColors: visual.supportingColors || visual.supporting_colors || [],
      gradient: String(visual.gradient || "solid brand surfaces with clear contrast"),
      typography: String(visual.typography || "Use the brand typography supplied in the manifest."),
      direction: String(visual.direction || "Use the supplied brand assets and keep the visual expression coherent, legible and recognisable."),
      logoRules: visual.logoRules || visual.logo_rules || logo.forbidden_uses || [],
    },
    editorialRules: value.editorialRules || value.editorial_rules || ["Do not invent facts, figures, quotes or credentials.", "Keep the source and the brand voice clearly distinguishable."],
  };
  return parseBrandProfile(JSON.stringify(profile));
}

export function mergeBrandProfiles(extra: BrandProfile[] = []) {
  return { ...PROFILES, ...Object.fromEntries(extra.map(profile => [profile.id, profile])) };
}

export function getBrandProfile(id = "smartball", extra: BrandProfile[] = []): BrandProfile {
  return mergeBrandProfiles(extra)[id] ?? SMARTBALL_BRAND;
}

export function listBrandProfiles(extra: BrandProfile[] = []): Pick<BrandProfile, "id" | "name">[] {
  return Object.values(mergeBrandProfiles(extra)).map(({ id, name }) => ({ id, name }));
}

export function buildBrandContext(brand: BrandProfile): string {
  return [
    `Eres el Content Engine de ${brand.name}.`,
    brand.verbal.boilerplate,
    `Posicionamiento: ${brand.positioning.category}. ${brand.positioning.promise}`,
    `Territorio emocional: ${brand.positioning.emotionalTerritory}`,
    `Voz: ${brand.verbal.toneAdjectives.join(", ")}.`,
    `Usa este léxico cuando aporte precisión: ${brand.verbal.lexiconUse.join(", ")}.`,
    `Evita: ${brand.verbal.neverSays.join(", ")}; ${brand.verbal.lexiconAvoid.join(", ")}.`,
    ...brand.editorialRules,
  ].join(" ");
}

export function buildVisualDirection(brand: BrandProfile, topic: string, adaptedContent: string, dimensions: string): string {
  return [
    `Create an editorial premium visual for a ${brand.name} content piece.`,
    `Topic: ${topic}.`,
    `Visual direction: ${brand.visual.direction}`,
    `Brand colors: primary ${brand.visual.primaryColor}, accent ${brand.visual.accentColor}, gradient ${brand.visual.gradient}.`,
    `Typography: ${brand.visual.typography}.`,
    `Adapted content: ${adaptedContent.slice(0, 650)}.`,
    `No illegible text, no invented logos, no visual effects that contradict the brand. Canvas: ${dimensions}.`,
  ].join(" ");
}
