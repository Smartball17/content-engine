import { generateImage } from "./_core/imageGeneration";
import { invokeLLM } from "./_core/llm";
import { buildBrandContext, buildVisualDirection, getBrandProfile, type BrandProfile } from "./brandProfiles";

export const PLATFORMS = ["linkedin", "instagram", "tiktok", "facebook", "x", "threads", "pinterest", "newsletter"] as const;
export type Platform = (typeof PLATFORMS)[number];
export type OutputType = "text" | "image" | "video" | "both";
export const CONTENT_TEMPLATES = ["no_template", "product_launch", "case_study", "thought_leadership", "industry_news", "how_to_guide", "data_insight"] as const;
export type ContentTemplate = (typeof CONTENT_TEMPLATES)[number];

type SourceInput = { title: string; summary: string; source: string; url: string; adaptationAngle?: string | null };
type Variant = { id: string; label: string; format: string; dimensions: string; instruction: string };

const VARIANTS: Record<Platform, Record<OutputType, Variant>> = {
  linkedin: {
    text: { id: "linkedin-post", label: "Post de LinkedIn", format: "Post", dimensions: "Texto", instruction: "Escribe un post de LinkedIn de máximo 1.300 caracteres: hook inequívoco, 3 ideas concretas, una implicación de negocio y pregunta final. Incluye 4-6 hashtags relevantes." },
    image: { id: "linkedin-card", label: "Artículo con imagen", format: "Article card", dimensions: "1200×627", instruction: "Crea un titular de máximo 70 caracteres, subtítulo, resumen de 120 palabras y dirección visual para una card de LinkedIn." },
    video: { id: "linkedin-video", label: "Guion de vídeo LinkedIn", format: "Vídeo 45-75 s", dimensions: "1920×1080", instruction: "Crea un guion de vídeo de LinkedIn con bloques de tiempo, AUDIO, VISUAL y TEXTO EN PANTALLA. Incluye hook, contexto, 3 implicaciones y CTA." },
    both: { id: "linkedin-carousel", label: "Carrusel de LinkedIn", format: "Carrusel 5 slides", dimensions: "1080×1080", instruction: "Crea un carrusel de 5 slides: portada-hook, tres insights y slide final CTA. Para cada slide: título corto y texto de máximo 28 palabras. Añade caption." },
  },
  instagram: {
    text: { id: "instagram-caption", label: "Caption de Instagram", format: "Feed post", dimensions: "Texto", instruction: "Escribe un caption de Instagram con hook, insight y CTA. Máximo 1.500 caracteres y 10-15 hashtags selectivos, sin tono adolescente." },
    image: { id: "instagram-feed", label: "Post visual de Instagram", format: "Feed visual", dimensions: "1080×1350", instruction: "Crea una propuesta de caption y dirección visual editorial para un post vertical 1080×1350. Incluye titular de la pieza y CTA." },
    video: { id: "instagram-reel", label: "Guion de Reel", format: "Reel 30-60 s", dimensions: "1080×1920", instruction: "Crea un guion de Reel vertical con timestamps, AUDIO, VISUAL, TEXTO EN PANTALLA, transiciones y CTA. Hook en los primeros 2 segundos." },
    both: { id: "instagram-carousel", label: "Carrusel de Instagram", format: "Carrusel 5 slides", dimensions: "1080×1350", instruction: "Crea un carrusel de 5 slides: cover, tres insights y CTA. Mantén cada slide por debajo de 25 palabras y añade caption." },
  },
  tiktok: {
    text: { id: "tiktok-caption", label: "Caption de TikTok", format: "Caption", dimensions: "Texto", instruction: "Escribe una caption breve para TikTok con hook, contexto y 5 hashtags. Debe acompañar una pieza educativa de negocio y tecnología." },
    image: { id: "tiktok-cover", label: "Cover de TikTok", format: "Cover", dimensions: "1080×1920", instruction: "Crea titular de cover, subtítulo, caption y dirección visual para una portada vertical de TikTok." },
    video: { id: "tiktok-script", label: "Guion de TikTok", format: "Vídeo 30-45 s", dimensions: "1080×1920", instruction: "Crea un guion de TikTok vertical con timestamps, AUDIO, VISUAL y TEXTO EN PANTALLA: hook, contexto, tres puntos, take estratégico y CTA." },
    both: { id: "tiktok-series", label: "Episodio de serie", format: "Vídeo 45-60 s", dimensions: "1080×1920", instruction: "Crea un episodio de una serie de actualidad tecnológica: intro, hook, historia, análisis, take de marca, CTA. Incluye caption y dirección de música." },
  },
  facebook: {
    text: { id: "facebook-post", label: "Post de Facebook", format: "Feed post", dimensions: "Texto", instruction: "Escribe un post de Facebook narrativo: apertura con curiosidad, 3 párrafos legibles en móvil, un dato específico y pregunta final." },
    image: { id: "facebook-card", label: "Card de Facebook", format: "Visual", dimensions: "1200×630", instruction: "Crea titular, texto de post y dirección visual para una pieza Facebook 1200×630 orientada a engagement y compartidos." },
    video: { id: "facebook-reel", label: "Guion de Facebook Reel", format: "Vídeo 45-75 s", dimensions: "1080×1920", instruction: "Crea un guion de Facebook Reel con AUDIO, VISUAL, texto en pantalla y CTA de compartir. Debe funcionar con espectadores profesionales." },
    both: { id: "facebook-story", label: "Secuencia de Stories", format: "Stories 4 frames", dimensions: "1080×1920", instruction: "Crea una secuencia de 4 Stories: hook, dos insights, take de marca y CTA. Especifica texto y dirección visual en cada frame." },
  },
  x: {
    text: { id: "x-post", label: "Post de X", format: "Post", dimensions: "Texto", instruction: "Escribe un post de X de máximo 280 caracteres, directo, útil y con una única idea fuerte. Usa máximo 2 hashtags." },
    image: { id: "x-card", label: "Card de X", format: "Visual", dimensions: "1600×900", instruction: "Crea un post de X y una dirección visual de card 1600×900: titular contundente, cifra o concepto y atribución de fuente." },
    video: { id: "x-video", label: "Guion de vídeo X", format: "Vídeo 20-45 s", dimensions: "1080×1920", instruction: "Crea guion corto para vídeo X que funcione sin audio: timestamps, AUDIO, VISUAL y texto en pantalla obligatorio." },
    both: { id: "x-thread", label: "Hilo de X", format: "Hilo 6 posts", dimensions: "Texto + visual", instruction: "Crea un hilo de 6 posts: hook, contexto, tres insights, take de marca y CTA. Máximo 280 caracteres cada post." },
  },
  threads: {
    text: { id: "threads-post", label: "Post de Threads", format: "Post", dimensions: "Texto", instruction: "Escribe un post de Threads de máximo 500 caracteres, con voz de colega inteligente: claro, genuino, sin hashtags y con pregunta final." },
    image: { id: "threads-card", label: "Post visual de Threads", format: "Visual", dimensions: "1080×1350", instruction: "Crea un post conversacional para Threads y dirección visual editorial para una imagen vertical 1080×1350." },
    video: { id: "threads-video", label: "Guion social de Threads", format: "Vídeo 30 s", dimensions: "1080×1920", instruction: "Crea un guion de vídeo conversacional para Threads con hook, explicación y pregunta para abrir conversación." },
    both: { id: "threads-chain", label: "Cadena de Threads", format: "Cadena 4 posts", dimensions: "Texto + visual", instruction: "Crea una cadena de 4 posts conectados: hook, contexto, análisis y pregunta de cierre. Cada uno debe poder leerse aislado." },
  },
  pinterest: {
    text: { id: "pinterest-pin-copy", label: "Copy de Pin", format: "Pin", dimensions: "Texto", instruction: "Crea título SEO, descripción de máximo 400 caracteres, 8 keywords y board sugerido para un Pin de Pinterest." },
    image: { id: "pinterest-pin", label: "Pin visual", format: "Standard pin", dimensions: "1000×1500", instruction: "Crea título, descripción SEO, texto overlay y dirección visual para un Pin vertical 1000×1500 educativo y guardable." },
    video: { id: "pinterest-video", label: "Guion de Video Pin", format: "Vídeo 30-45 s", dimensions: "1000×1500", instruction: "Crea un Video Pin vertical que funcione sin audio: timestamps, texto overlay, visual, CTA de guardar y descripción SEO." },
    both: { id: "pinterest-idea", label: "Idea Pin", format: "Idea pin 5 páginas", dimensions: "1080×1920", instruction: "Crea un Idea Pin de 5 páginas: cover, tres ideas y CTA. Cada página con texto overlay y dirección visual." },
  },
  newsletter: {
    text: { id: "newsletter-brief", label: "Brief de newsletter", format: "Quick brief", dimensions: "Email", instruction: "Crea asunto, titular, resumen de dos párrafos, por qué importa y fuente. Tono ejecutivo, claro y útil." },
    image: { id: "newsletter-hero", label: "Hero de newsletter", format: "Hero + texto", dimensions: "1200×675", instruction: "Crea asunto, titular, cuerpo breve y dirección visual para el hero de una newsletter de la marca seleccionada." },
    video: { id: "newsletter-video", label: "Guion para vídeo embebido", format: "Vídeo 45 s", dimensions: "1920×1080", instruction: "Crea guion de vídeo breve para acompañar una newsletter: apertura, noticia, implicación y CTA. Incluye asunto y copy de introducción." },
    both: { id: "newsletter-deepdive", label: "Deep dive", format: "Deep dive", dimensions: "Email + visual", instruction: "Crea una sección de newsletter profunda: asunto, titular, contexto, análisis, implicación para líderes, tres acciones y fuente." },
  },
};

const TEMPLATE_INSTRUCTIONS: Record<ContentTemplate, string> = {
  no_template: "Usa la estructura editorial más adecuada para el canal y la señal.",
  product_launch: "Enfoca la pieza como lanzamiento: problema, novedad, beneficio demostrable, lectura estratégica y siguiente paso.",
  case_study: "Enfoca la pieza como caso: contexto, decisión, ejecución, resultado y aprendizaje transferible. No inventes resultados.",
  thought_leadership: "Enfoca la pieza como una postura argumentada: tesis, evidencia, implicación y pregunta que eleve la conversación.",
  industry_news: "Enfoca la pieza como noticia sectorial: qué ha pasado, por qué importa y qué deben vigilar los líderes.",
  how_to_guide: "Enfoca la pieza como guía práctica: situación, pasos concretos, error habitual y recomendación final.",
  data_insight: "Enfoca la pieza alrededor del dato disponible: qué mide, interpretación, límite y decisión que puede informar.",
};

export function getVariant(platform: Platform, outputType: OutputType) { return VARIANTS[platform][outputType]; }
export function getVariants() { return PLATFORMS.flatMap(platform => (Object.keys(VARIANTS[platform]) as OutputType[]).map(outputType => ({ platform, outputType, ...VARIANTS[platform][outputType] }))); }

export async function generatePiece(source: SourceInput, platform: Platform, outputType: OutputType, contentTemplate: ContentTemplate = "no_template", brief?: string, brand: BrandProfile = getBrandProfile(), language: "es" | "en" = "es") {
  const variant = getVariant(platform, outputType);
  const response = await invokeLLM({
    messages: [
      { role: "system", content: buildBrandContext(brand) },
      { role: "user", content: `${variant.instruction}\n\nOUTPUT LANGUAGE\nWrite the complete piece in ${language === "en" ? "natural international English" : "European Spanish"}. Localize the tone rather than translating idioms literally.\n\nPLANTILLA EDITORIAL\n${TEMPLATE_INSTRUCTIONS[contentTemplate]}${brief ? `\n\nBRIEF EDITORIAL DEL USUARIO\n${brief}` : ""}\n\nFUENTE\nTítulo: ${source.title}\nMedio: ${source.source}\nURL: ${source.url}\nResumen: ${source.summary}\nÁngulo sugerido: ${source.adaptationAngle || "lectura estratégica"}\n\nReglas: aplica estrictamente la voz y restricciones de la marca seleccionada; atribuye la fuente al final cuando exista y no inventes cifras ni citas.` },
    ],
  });
  const textContent = typeof response.choices?.[0]?.message?.content === "string" ? response.choices[0].message.content : "";
  if (!textContent) throw new Error("El modelo no devolvió contenido reutilizable.");

  let imageUrl: string | undefined;
  if (outputType === "image" || outputType === "both") {
    const image = await generateImage({
      prompt: buildVisualDirection(brand, source.title, textContent, variant.dimensions),
    });
    imageUrl = image.url;
  }
  return { ...variant, textContent, imageUrl };
}
