import { and, desc, eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { articles, brandProfiles, contentPieces, customFeeds, feedScans, type InsertArticle, type InsertBrandProfile, type InsertContentPiece, type InsertFeedScan, type InsertUser, users } from "../drizzle/schema";
import { ENV } from "./_core/env";

let database: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!database && process.env.DATABASE_URL) database = drizzle(process.env.DATABASE_URL);
  return database;
}

export async function upsertUser(user: InsertUser) {
  const db = await getDb();
  if (!db) return;
  const values: InsertUser = { ...user, role: user.role ?? (user.openId === ENV.ownerOpenId ? "admin" : "user"), lastSignedIn: new Date() };
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: { name: values.name, email: values.email, loginMethod: values.loginMethod, lastSignedIn: new Date(), role: values.role } });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  return (await db.select().from(users).where(eq(users.openId, openId)).limit(1))[0];
}

function requireDb(db: Awaited<ReturnType<typeof getDb>>) {
  if (!db) throw new Error("La base de datos no está disponible.");
  return db;
}

export async function createFeedScan(payload: InsertFeedScan) {
  const result = await requireDb(await getDb()).insert(feedScans).values(payload);
  return Number(result[0].insertId);
}
export async function updateFeedScan(id: number, payload: Partial<InsertFeedScan>) {
  await requireDb(await getDb()).update(feedScans).set(payload).where(eq(feedScans.id, id));
}
export async function listScans(ownerId: number) {
  return requireDb(await getDb()).select().from(feedScans).where(eq(feedScans.ownerId, ownerId)).orderBy(desc(feedScans.createdAt)).limit(30);
}
export async function getOwnedScan(id: number, ownerId: number) {
  return (await requireDb(await getDb()).select().from(feedScans).where(and(eq(feedScans.id, id), eq(feedScans.ownerId, ownerId))).limit(1))[0];
}
export async function insertArticles(payload: InsertArticle[]) {
  if (payload.length) await requireDb(await getDb()).insert(articles).values(payload);
}
export async function getArticlesByScan(scanId: number) {
  return requireDb(await getDb()).select().from(articles).where(eq(articles.scanId, scanId)).orderBy(desc(articles.score));
}
export async function getOwnedArticle(id: number, ownerId: number) {
  const article = (await requireDb(await getDb()).select().from(articles).where(eq(articles.id, id)).limit(1))[0];
  if (!article || !(await getOwnedScan(article.scanId, ownerId))) return undefined;
  return article;
}
export async function markAdapted(id: number) {
  await requireDb(await getDb()).update(articles).set({ isAdapted: 1 }).where(eq(articles.id, id));
}
export async function savePiece(payload: InsertContentPiece) {
  const result = await requireDb(await getDb()).insert(contentPieces).values(payload);
  return Number(result[0].insertId);
}
export async function listPieces(ownerId: number, articleId?: number) {
  const db = requireDb(await getDb());
  const pieces = articleId ? await db.select().from(contentPieces).where(eq(contentPieces.articleId, articleId)).orderBy(desc(contentPieces.createdAt)) : await db.select().from(contentPieces).orderBy(desc(contentPieces.createdAt)).limit(100);
  const owned: typeof pieces = [];
  for (const piece of pieces) if (await getOwnedArticle(piece.articleId, ownerId)) owned.push(piece);
  return owned;
}
export async function toggleFavorite(id: number, ownerId: number) {
  const piece = (await listPieces(ownerId)).find(item => item.id === id);
  if (!piece) throw new Error("Pieza no encontrada.");
  const next = piece.isFavorite ? 0 : 1;
  await requireDb(await getDb()).update(contentPieces).set({ isFavorite: next }).where(eq(contentPieces.id, id));
  return next === 1;
}
export async function addCustomFeed(ownerId: number, name: string, url: string, category: string) {
  const result = await requireDb(await getDb()).insert(customFeeds).values({ ownerId, name, url, category });
  return Number(result[0].insertId);
}
export async function listCustomFeeds(ownerId: number, onlyActive = false) {
  const db = requireDb(await getDb());
  return db.select().from(customFeeds).where(onlyActive ? and(eq(customFeeds.ownerId, ownerId), eq(customFeeds.isActive, 1)) : eq(customFeeds.ownerId, ownerId)).orderBy(desc(customFeeds.createdAt));
}
export async function toggleCustomFeed(id: number, ownerId: number, isActive: boolean) {
  await requireDb(await getDb()).update(customFeeds).set({ isActive: isActive ? 1 : 0 }).where(and(eq(customFeeds.id, id), eq(customFeeds.ownerId, ownerId)));
}
export async function deleteCustomFeed(id: number, ownerId: number) {
  await requireDb(await getDb()).delete(customFeeds).where(and(eq(customFeeds.id, id), eq(customFeeds.ownerId, ownerId)));
}

export async function listOwnedBrandProfiles(ownerId: number) {
  return requireDb(await getDb()).select().from(brandProfiles).where(eq(brandProfiles.ownerId, ownerId)).orderBy(desc(brandProfiles.createdAt));
}

export async function saveBrandProfile(payload: InsertBrandProfile) {
  const db = requireDb(await getDb());
  const existing = await db.select({ id: brandProfiles.id }).from(brandProfiles).where(and(eq(brandProfiles.ownerId, payload.ownerId), eq(brandProfiles.brandId, payload.brandId))).limit(1);
  if (existing[0]) {
    await db.update(brandProfiles).set({ name: payload.name, profileJson: payload.profileJson }).where(eq(brandProfiles.id, existing[0].id));
    return existing[0].id;
  }
  const result = await db.insert(brandProfiles).values(payload);
  return Number(result[0].insertId);
}
