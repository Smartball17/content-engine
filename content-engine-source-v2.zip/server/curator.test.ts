import { describe, expect, it } from "vitest";
import { createTextArticle, importArticleUrl, scoreArticle } from "./scanner";
import { CONTENT_TEMPLATES, getVariant } from "./contentGenerator";
import { buildBrandContext, buildVisualDirection, getBrandProfile, listBrandProfiles, normalizeImportedBrandProfile } from "./brandProfiles";
import { PRODUCT_GUIDE_STEPS, PRODUCT_GUIDE_STORAGE_KEY } from "../shared/productGuide";

describe("Content Engine recovered logic", () => {
  it("scores an article and assigns a supported priority", () => {
    const result = scoreArticle("OpenAI launches a new agent workflow", "A practical enterprise AI automation guide for business teams.", new Date().toISOString());
    expect(["HIGH", "MEDIUM", "LOW", "SKIP"]).toContain(result.priority);
    expect(result.score).toBeGreaterThanOrEqual(0);
  });
  it("turns manual input into a persistable article", () => {
    const article = createTextArticle("Las compañías que traducen las señales de IA en decisiones operativas crearán una ventaja difícil de replicar.");
    expect(article.source).toBe("Entrada manual");
    expect(article.title.length).toBeGreaterThan(4);
  });
  it("blocks private URLs before attempting an import", async () => {
    await expect(importArticleUrl("http://127.0.0.1/internal")).rejects.toThrow("pública");
  });
  it("exposes a variant for every requested platform and output", () => {
    const variant = getVariant("instagram", "video");
    expect(variant.dimensions).toContain("1080");
    expect(variant.label).toContain("Reel");
  });
  it("keeps the recovered editorial template matrix available", () => {
    expect(CONTENT_TEMPLATES).toEqual(expect.arrayContaining(["product_launch", "case_study", "thought_leadership", "industry_news", "how_to_guide", "data_insight"]));
  });
  it("exposes a normalized SMARTBALL brand profile", () => {
    const brand = getBrandProfile("smartball");
    expect(brand.name).toBe("SMARTBALL");
    expect(brand.visual.primaryColor).toBe("#0D1B3E");
    expect(listBrandProfiles()).toEqual([{ id: "smartball", name: "SMARTBALL" }]);
  });
  it("builds prompts from the selected brand instead of hardcoded engine identity", () => {
    const brand = getBrandProfile();
    expect(buildBrandContext(brand)).toContain("sobrio");
    expect(buildVisualDirection(brand, "Una señal", "Un contenido", "1080×1080")).toContain("#0081FB");
  });
  it("normalizes a Brand Identity Builder manifest for the content engine", () => {
    const brand = normalizeImportedBrandProfile({
      schema_version: "2.0",
      brand: { name: "Northstar", slug: "northstar" },
      languages: ["en-GB"],
      positioning: { category: "Strategy", promise: "Make complexity useful", emotional_territory: "Calm confidence" },
      verbal: { boilerplate: "Northstar helps teams decide.", tone_adjectives: ["clear"], never_says: [], lexicon_use: ["evidence"], lexicon_avoid: [] },
      logo: { forbidden_uses: ["distort"] },
    });
    expect(brand.id).toBe("northstar");
    expect(brand.name).toBe("Northstar");
    expect(brand.visual.logoRules).toContain("distort");
  });
  it("keeps the onboarding guide concrete and dismissible", () => {
    expect(PRODUCT_GUIDE_STEPS.es.map(step => step.title)).toEqual(["Detecta", "Crea", "Guarda"]);
    expect(PRODUCT_GUIDE_STEPS.en.map(step => step.title)).toEqual(["Discover", "Create", "Save"]);
    expect(PRODUCT_GUIDE_STORAGE_KEY).toContain("guide-dismissed");
  });
});
