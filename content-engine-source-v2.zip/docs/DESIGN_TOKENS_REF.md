# Design Tokens Reference (extracted from Apple skill)

## Dark appearance tokens
- --bg: #000000
- --bg-secondary: #1c1c1e
- --bg-tertiary: #2c2c2e
- --bg-elevated: #1c1c1e
- --label: #f5f5f7
- --label-secondary: rgb(235 235 245 / 0.6)
- --label-tertiary: rgb(235 235 245 / 0.3)
- --label-quaternary: rgb(235 235 245 / 0.18)
- --separator: rgb(84 84 88 / 0.6)
- --fill: rgb(120 120 128 / 0.36)
- --fill-secondary: rgb(120 120 128 / 0.24)
- --accent: #0a84ff
- --accent-hover: #409cff
- --success: #30d158
- --warning: #ff9f0a
- --destructive: #ff453a
- --material-thin: rgb(28 28 30 / 0.72)
- --material-regular: rgb(28 28 30 / 0.82)
- --material-thick: rgb(28 28 30 / 0.94)
- --material-blur: saturate(180%) blur(20px)
- --shadow-sm: 0 1px 2px rgb(0 0 0 / 0.3)
- --shadow-md: 0 4px 12px rgb(0 0 0 / 0.4)
- --shadow-lg: 0 12px 32px rgb(0 0 0 / 0.5)

## Motion
- --ease-out-soft: cubic-bezier(0.16, 1, 0.3, 1)
- --ease-standard: cubic-bezier(0.4, 0, 0.2, 1)
- --ease-sheet: cubic-bezier(0.32, 0.72, 0, 1)
- --duration-fast: 140ms
- --duration-base: 300ms
- --duration-slow: 520ms

## Typography
- Font: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif
- Mono: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, monospace
- Weights: 400, 500, 600, 700 only
- Body: 17px (1.0625rem), line-height 1.55
- Title-2: clamp(1.5rem, 3vw, 2.25rem), weight 600, tracking -0.01em
- Title-3: clamp(1.25rem, 2vw, 1.5rem), weight 600, tracking -0.005em
- Footnote: 0.8125rem, line-height 1.45
- Caption: 0.75rem, line-height 1.4, tracking 0.01em
- Measure body: max-width 38rem

## Spacing (4px base)
- 4, 8, 12, 16, 24, 32, 48, 64, 96, 128, 192
- Section vertical: 96px mobile, 128-192px desktop
- Content gutters: 20px mobile, 24px tablet, 32px+ desktop
- Max content width: 980-1280px

## Radii
- --radius-sm: 8px (inputs, chips)
- --radius-md: 12px (buttons, cards)
- --radius-lg: 20px (panels, sheets)
- --radius-full: 999px (pills, capsules)

## Controls
- Min hit target: 44x44px touch
- Focus: 3px accent ring, 2px offset
- Button press: scale(0.97) on :active, 160ms ease-out
- One primary action per view

## Utility app shell pattern
- Thin persistent top bar or narrow sidebar
- Content edge to edge
- Controls on floating translucent layer above content
- Empty states: one line + one action button
- Loading: skeletons matching final layout shape

## Key rules
- One typeface family only
- One accent colour only
- Semantic tokens only (no hex in components)
- Group by whitespace first, separators second, boxes last
- Body measure 45-75 characters
- Never centred paragraphs longer than 2 lines
- Motion only where it explains something
- prefers-reduced-motion always honoured
