# Content Engine — Release notes

## Current release

- Discover: RSS scanner, free text analysis and secure URL import.
- Brand Studio: import and activate JSON/ZIP Brand Profiles.
- Create: eight channel variants, text/image/video/both output modes, bilingual generation and live preview.
- Library: filtering, favourites and JSON/ZIP/PDF/DOCX exports.
- Backend: authenticated tRPC procedures, MySQL persistence and per-user ownership checks.

## Honest scope

This is a validated functional beta, not yet a public-scale SaaS. Production gaps are documented in `docs/PRODUCTION_READINESS_AUDIT.md`: rate limiting, stronger operational observability, dependency remediation, export hardening and integration contracts remain before broad launch.
