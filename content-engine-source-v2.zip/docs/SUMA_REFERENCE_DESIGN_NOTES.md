# Referencia de diseño: sumaweb.manus.space

Fuente visual y estructural consultada: https://sumaweb.manus.space/

## Patrones reutilizables

- Lienzo editorial claro con mucho espacio en blanco.
- Índice lateral persistente para orientarse en un sistema con varias secciones.
- Encabezado de contexto antes del titular principal.
- Titulares grandes de varias líneas con una idea fuerte.
- Bloques de evidencia y fuentes visibles junto a la narrativa.
- Controles de variante visual, modo claro/oscuro y navegación de índice.
- Imágenes grandes usadas como contexto editorial, con atribución y límites explícitos.
- Separación clara entre conclusión, evidencia y decisión.

## Adaptación decidida para SMARTBALL Content Engine

- Mantener el flujo operativo Discover → Create → Library; no convertirlo en un informe largo.
- Cambiar el fondo negro por un lienzo editorial claro, conservando Navy Dark `#0D1B3E` y Bright Blue `#0081FB` como identidad SMARTBALL.
- Usar un índice lateral compacto para navegar por las tres áreas del producto.
- Usar titulares editoriales y una señal visual principal sin copiar logo, tipografía ni activos de SUMA.
- Añadir idioma de interfaz ES/EN y selector independiente de idioma de generación.

## Límites

La web consultada es un producto de SUMA y contiene identidad, datos y contenidos propios. Solo se reutilizan patrones de jerarquía y estructura, no su marca, copy, logos, assets ni afirmaciones.
