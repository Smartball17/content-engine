# SMARTBALL Content Engine — Porting and Operations

## Qué se recuperó de Google Drive

La aplicación se ha construido a partir de los artefactos funcionales recuperados del proyecto original de Linkhub. No se ha tratado como una recreación visual aislada: el diseño conserva una identidad propia de producto, mientras que la generación de las piezas aplica la identidad verbal y visual de **SMARTBALL**.

| Artefacto original recuperado | Uso en este proyecto |
| --- | --- |
| `server/scanner.ts` | Portado y reforzado en `server/scanner.ts`: fuentes RSS, parsing, filtro temporal y scoring de señales. El escaneo se ejecuta en paralelo para reducir esperas. |
| `server/contentGenerator.ts` | Portado como `server/contentGenerator.ts` y adaptado al tono SMARTBALL. Mantiene las ocho plataformas y los cuatro tipos de salida. |
| `drizzle/schema.ts` y `server/db.ts` | Reconstruidos sobre el template actual con tablas de scans, artículos, piezas y fuentes personalizadas. |
| `server/routers.ts` | Portado a tRPC con procedimientos autenticados para scan, texto libre, URL import, generación, histórico y librería. |
| `CuratorScanner.tsx` | Reinterpretado como `client/src/pages/Home.tsx`, con los flujos de entrada, resultados priorizados y generación multicanal. |
| Historial/librería del original | Implementado en `client/src/pages/Library.tsx`, que consulta outputs persistidos y permite marcarlos como favoritos. |

## Dependencias operativas

| Servicio | Cómo se usa | Nota operativa |
| --- | --- | --- |
| Manus OAuth | Protege el acceso a scanner, historial y generación. | Cada usuario debe iniciar sesión antes de usar el motor. |
| Base de datos administrada | Guarda scans, artículos, fuentes personalizadas y piezas. | `DATABASE_URL` está inyectado por la plataforma; no se configura en el cliente. |
| Fuentes RSS públicas | El scanner consulta feeds de IA y tecnología. | Un feed puede fallar, cambiar de formato o no devolver artículos; el resto del scan continúa. |
| LLM integrado | Redacta una pieza por plataforma seleccionada. | Cada plataforma seleccionada implica una llamada de IA. Es un coste variable del proyecto. |
| Generación de imagen integrada | Se utiliza en los modos **Image** y **Both**. | Es más lenta y genera coste adicional. Por defecto, conviene empezar con **Text** y pocas plataformas. |

## Controles de seguridad y coste

La importación de URL rechaza destinos privados, locales y redirecciones automáticas. La generación no se lanza sin seleccionar una señal ni plataformas. La interfaz arranca con todas las plataformas visibles para expresar cobertura, pero la recomendación de uso es seleccionar únicamente los canales que se vayan a revisar.

## Validación E2E realizada

El 16 de agosto de 2026 se realizó una prueba autenticada de extremo a extremo en el entorno de desarrollo:

1. Se inició sesión como propietario del proyecto.
2. Se ejecutó un scan RSS real de los últimos tres días.
3. Se persistió el **Scan #1** con **81 artículos**, incluyendo **2 señales HIGH** y **20 MEDIUM**.
4. Se abrió el detalle del scan y se recuperaron los artículos desde la base de datos.
5. Se seleccionó una señal HIGH de TechCrunch y se generó una pieza real de **LinkedIn / Text** con el modelo integrado.
6. Se confirmó que la pieza aparece después en la **Library**, fuera del flujo del scanner.

La validación se amplió después con una fuente RSS personalizada, una entrada de texto libre, una importación URL pública, el rechazo visible de una URL privada, la selección de la plantilla **Thought Leadership**, una pieza de LinkedIn en texto y un mockup visual de LinkedIn persistido en almacenamiento. También se verificó el pipeline visible —Source, Score, Select, Generate y Library— junto con la confirmación obligatoria antes de generar múltiples piezas o outputs visuales.

Como cierre de la matriz de outputs, se verificó una pieza real **Video** de LinkedIn y una pieza real **Both** de LinkedIn —carrusel con texto e imagen generada—. Ambos resultados se persistieron en la misma señal seleccionada. La generación visual incorpora un límite de espera de 90 segundos para evitar que una solicitud lenta bloquee la interfaz indefinidamente.

## Capacidades preparadas y siguientes límites deliberados

El núcleo operativo está activo: texto libre, URL import, scanner RSS, scoring, guardado, selección multicanal, generación LLM, imagen bajo demanda, outputs persistentes, librería y favoritos.

El auto-scan programado no se ha activado todavía. Requiere publicar la aplicación y crear una tarea Heartbeat contra la URL de producción; no se usa ningún temporizador interno porque no sobreviviría al autoscaling. La integración con una cuenta de Canva tampoco está activa: los modos actuales generan contenido e imagen mediante IA, no archivos editables en Canva.

La interfaz muestra de forma permanente **AI Engine activo** y **Canva · no conectado**. Pulsar Canva informa de que hace falta una cuenta autenticada; no simula una exportación ni un diseño editable inexistente.
