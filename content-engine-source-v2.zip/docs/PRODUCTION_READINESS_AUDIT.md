# Content Engine — Production Readiness Audit

**Fecha:** 13 de octubre de 2026  
**Alcance:** código fuente, esquema, router, scanner, generador, UI, tests, build y dependencias locales.  
**Objetivo evaluado:** beta privada y posible evolución a producto SaaS.  
**No evaluado:** pentest externo, prueba de carga, configuración real de producción, restauración de backups, métricas reales, contratos de proveedores, cumplimiento legal y flujo de pagos.

## Veredicto ejecutivo

**Conclusión: beta privada con restricciones; no producción pública amplia todavía.** No es un simple ejercicio de diseño: el flujo Discover → Create → Library tiene backend real, persistencia MySQL, autenticación, generación LLM/imagen, importación de Brand Profiles y exportaciones. La evidencia local es sólida para una beta controlada: `pnpm check`, 10 tests y `pnpm build` pasan.

Pero afirmar que está «100% lista» sería falso. Hay brechas relevantes antes de abrirla a usuarios o cobrar: **dependencias con vulnerabilidades conocidas**, ausencia visible de rate limiting y cuotas server-side, ausencia de observabilidad operativa suficiente, controles de coste que no constituyen un límite real, y autorización que es de usuario autenticado pero no restringe el motor al propietario/admin. La recomendación es seguir desarrollándola, pero como **beta privada de un solo propietario o grupo muy reducido**, no como SaaS abierto.

## Evidencia verificada

- Router tRPC con procedimientos protegidos por autenticación para scanner, importación, generación, perfiles de marca y biblioteca (`server/routers.ts`).
- Aislamiento por `ownerId` en scans, feeds, artículos, piezas y Brand Profiles (`server/db.ts`).
- Importación URL con timeout, `redirect: "error"` y validación contra IPs privadas/locales (`server/scanner.ts`).
- Generación real vía LLM e imagen, no solo mock visual (`server/contentGenerator.ts`).
- Persistencia MySQL/Drizzle y migraciones de perfiles de marca y trazabilidad de la identidad usada.
- Exportaciones locales de JSON, ZIP, PDF y DOCX en Library.
- Validación local: TypeScript OK, tests OK (2 archivos / 10 tests), build OK.
- Búsqueda de secretos accidentales en archivos rastreados: no se encontraron patrones evidentes de API keys o claves privadas.

## Hallazgos priorizados

| ID | Severidad | Hallazgo | Evidencia / impacto | Acción |
|---|---|---|---|---|
| P1-01 | **P1 Alto** | Dependencias vulnerables | `pnpm audit --prod --audit-level high` reporta 81 vulnerabilidades: 18 high y 1 critical. Aparecen `axios@1.12.2`, `form-data@4.0.4` y `nanoid@5.1.6`, entre otras rutas transitivas. | Actualizar dependencias y lockfile; repetir auditoría; bloquear release público si las vulnerabilidades alcanzan runtime o cadena de entrada. |
| P1-02 | **P1 Alto** | Sin rate limiting ni cuotas server-side visibles | `runScan`, `importUrl` y `generate` están protegidos por login, pero no muestran límite por usuario/IP. `generate` acepta hasta 8 plataformas y puede invocar LLM e imagen por petición. | Añadir límites por usuario y endpoint, idempotencia básica, backoff y presupuesto diario/mensual. El frontend no es un control de coste. |
| P1-03 | **P1 Alto** | Autenticación no equivale a acceso exclusivo del propietario | Las operaciones principales usan `protectedProcedure`; no existe un `adminProcedure` aplicado al router del motor. Cualquier usuario autenticado podría acceder si la app se abre públicamente. | Para `smartballai.com`, envolver el módulo con autorización explícita de owner/admin y comprobarlo en backend, no solo ocultar navegación. |
| P1-04 | **P1 Alto** | Falta evidencia de operación real | No se inspeccionaron alertas, logs estructurados, métricas, backups restaurables, rollback ni SLO. Un fallo de proveedor LLM/RSS/DB puede quedar en error genérico o sin diagnóstico suficiente. | Añadir error tracking, logs sin datos sensibles, métricas de latencia/coste/errores, health checks útiles, backup probado y runbook. |
| P2-01 | **P2 Medio** | SSRF endurecido, pero no demostrado contra DNS rebinding o todos los formatos | El scanner bloquea rangos privados/locales y evita redirects, lo cual es positivo. No hay prueba de seguridad exhaustiva ni garantía frente a todos los casos de resolución y esquemas alternativos. | Mantener allowlist `http/https`, resolver y validar destino final, limitar tamaño/respuesta, bloquear metadata endpoints y añadir tests negativos. |
| P2-02 | **P2 Medio** | Exportación en navegador tiene límites de fiabilidad | PDF/DOCX/ZIP dependen del navegador y de cargar imágenes remotas. CORS, imágenes grandes o piezas numerosas pueden fallar; no hay test E2E de exportaciones. | Testear exportaciones con piezas reales y fallos de imagen; añadir descarga server-side solo si el uso lo exige. |
| P2-03 | **P2 Medio** | Cobertura de tests insuficiente para flujos críticos | Los 10 tests cubren curator/auth, pero no hay E2E real del flujo login → scan → generate → library → export, ni pruebas de aislamiento multiusuario, límites, proveedor caído o migraciones aplicadas. | Añadir tests de integración y un smoke E2E gratuito en staging antes de abrir beta. |
| P2-04 | **P2 Medio** | Rendimiento de Library mejorable | `listPieces` carga hasta 100 piezas y después verifica ownership pieza a pieza mediante consultas adicionales. Funciona a pequeña escala, pero puede convertirse en N+1. | Resolver ownership con joins/consultas acotadas y paginación cuando el volumen lo justifique. No sobredimensionar todavía. |
| P3-01 | **P3 Bajo** | Build con chunks grandes | Vite avisa de chunks >500 kB, aunque las exportaciones pesadas ya usan carga diferida. | Separar más chunks si afecta carga real; no es gate de beta privada. |
| P3-02 | **P3 Bajo** | Advertencia de configuración pnpm | pnpm ignora el campo `pnpm` del package.json en la versión actual y avisa de `patchedDependencies`/`overrides`. | Migrar esa configuración a `pnpm-workspace.yaml` o formato soportado y documentarlo. |

## Estado por dominio

- **Producto:** fuerte para beta. El valor es claro: descubrir una señal, convertirla en contenido de marca y adaptarla por canal.
- **Diseño/UX:** bueno y diferenciable; el flujo y Brand Studio son comprensibles. Falta demostrarlo con usuarios reales, especialmente exportación y onboarding.
- **Arquitectura:** funcional y razonable para un MVP; todavía concentrada en pocos módulos grandes y sin límites operativos suficientes.
- **Identidad/permisos:** aislamiento por usuario está implementado en varias consultas; falta el gate owner/admin si el destino es una herramienta privada.
- **Seguridad:** validación básica de URL y búsqueda de secretos positiva; dependencia vulnerable y ausencia de pruebas de abuso impiden aprobar producción abierta.
- **Datos/privacidad:** se envían fuentes y briefs a servicios LLM/imagen. Falta política clara de retención, borrado, consentimiento y documentación de proveedores. Esto requiere revisión legal específica si se comercializa.
- **Coste:** el coste real por pieza no está medido ni limitado en backend. Generar ocho plataformas con imagen puede multiplicar consumo por acción.
- **Integraciones:** RSS y Manus AI están integrados; Canva, publicación directa en redes y video real no están integrados como flujos de producción completos.
- **Pagos:** no hay pagos implementados; no tiene sentido añadir planes de pago antes de resolver límites, medición, seguridad y valor repetido.

## Plan recomendado por coste/beneficio

### Fase 0 — antes de cualquier beta externa

1. Actualizar dependencias vulnerables y repetir `pnpm audit`.
2. Añadir rate limits y cuotas server-side para scan/import/generate.
3. Crear `adminOnlyProcedure` para el despliegue privado en `smartballai.com`.
4. Añadir logs y errores accionables sin guardar prompts o contenidos sensibles innecesarios.
5. Escribir tests de aislamiento multiusuario y de límites de coste.

### Fase 1 — beta privada

1. Probar con 3–10 usuarios o equipos reales.
2. Medir tiempo hasta primera pieza útil, tasa de exportación, regeneraciones, coste por generación y fallos por proveedor.
3. Añadir feedback de calidad por plataforma y Brand Identity.
4. Documentar qué significa «video»: actualmente es principalmente adaptación/guion/asset según el output disponible, no un pipeline audiovisual completo equivalente a Canva.

### Fase 2 — producto comercial

Solo si los datos de beta lo justifican:

- planes Free/Pro con límites medidos;
- billing y webhooks idempotentes;
- workspace/organizaciones y roles;
- publicación directa o integraciones oficiales por plataforma;
- observabilidad y backups restaurables;
- soporte y política de privacidad.

## Decisión

**Sí merece seguir desarrollándose.** Tiene producto real detrás y resuelve un flujo reconocible; no debe quedarse como ejercicio de diseño. La decisión correcta es **no convertirlo todavía en SaaS de pago abierto**. Primero hay que cerrar P1-01, P1-02, P1-03 y P1-04, y validar uso real. El siguiente salto de valor no es añadir más plataformas: es hacer fiable, medible y económicamente controlable el flujo que ya existe.
