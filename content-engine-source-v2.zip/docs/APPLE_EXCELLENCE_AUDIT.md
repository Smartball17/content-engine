# Auditoría integral — SMARTBALL Content Engine

## Veredicto directo

El producto **ya funciona**, pero su experiencia no está todavía al nivel de un producto excelente. Ahora mismo se percibe como una herramienta potente que muestra demasiadas decisiones simultáneamente. La lógica es sólida; la interfaz aún no convierte esa lógica en una experiencia inevitable, clara y calmada.

> **Principio rector propuesto:** una persona de SMARTBALL debe poder transformar una señal relevante en una pieza lista para revisión editorial, para un canal concreto, sin tener que interpretar la herramienta ni pensar en su arquitectura.

La auditoría mecánica sobre la interfaz detectó **64 errores de color hardcodeado** y **12 advertencias** relacionadas con tokens, estados de foco y apariencia adaptativa. Esto no significa que la interfaz sea mala; significa que su sistema visual todavía no está gobernado por una base de diseño sólida.

| Dimensión | Estado actual | Juicio directo |
| --- | --- | --- |
| Motor funcional | Alto | Scanner, persistencia, generación y librería ya demuestran utilidad real. |
| Claridad de flujo | Medio | Se entienden las capacidades, pero hay demasiados controles visibles al mismo tiempo. |
| Jerarquía visual | Medio-bajo | Scanner, pipeline, scans, configuración, outputs y specialists compiten por atención. |
| Craft visual | Medio-bajo | Existe una buena base dark-product, pero hay exceso de bordes, colores de canal y microtipografía. |
| Gestión de coste | Alta | La confirmación multicanal y visual es honesta y correcta. |
| Escalabilidad UX | Media | La página única crecerá peor cada vez que se añada una capacidad. |

## El problema principal

La pantalla actual responde a demasiadas preguntas a la vez: cómo introducir una fuente, cómo gestionar RSS, qué scan abrir, qué señal seleccionar, qué formato elegir, dónde quedan los outputs y qué especialistas intervienen. Cada bloque funciona, pero todos compiten por ser el centro de atención.

El enfoque Apple no consiste en hacer una interfaz más vacía; consiste en hacer que **cada pantalla responda una sola pregunta**. Para este producto, la pregunta de la pantalla principal debe ser: **“¿Qué señal quieres convertir en una pieza?”**. La configuración avanzada debe aparecer solo cuando la señal ya está elegida.

## Diagnóstico de diseño

### 1. La arquitectura debe pasar de página única a workspace por etapas

La home actual concentra Discover, Compose, Create y Library. La evolución correcta es separar mentalmente esas capas sin romper la velocidad de uso.

| Área propuesta | Pregunta que responde | Contenido principal | Acción primaria |
| --- | --- | --- | --- |
| **Discover** | ¿Qué merece atención? | Scanner, scans recientes, fuentes y señales priorizadas. | `Escanear fuentes` |
| **Compose** | ¿Cuál es el ángulo SMARTBALL? | Fuente seleccionada, scoring, resumen, ángulo y plantilla. | `Crear brief` |
| **Create** | ¿Qué pieza necesito para qué canal? | Canal, formato, preview y estimación de coste. | `Generar pieza` |
| **Library** | ¿Qué contenido ya tenemos? | Filtros, favoritos, estado editorial y outputs. | `Abrir pieza` |

Esto no exige hacer cuatro aplicaciones distintas. Puede ser un flujo con navegación persistente y transiciones contenidas. Lo importante es que el usuario no vea configuraciones que todavía no necesita.

### 2. El output debe ser el protagonista, no la configuración

Hoy el panel de configuración ocupa una posición muy dominante y los outputs quedan como una consecuencia lateral. En un Content Engine excelente, la pieza generada debe convertirse en el objeto más importante de la pantalla después de crearla.

La mejora clave consiste en crear un **canvas de revisión**: preview grande de la pieza, fuente y ángulo editorial visibles, acciones de copia/guardado/favorito, y una configuración condensada en una barra lateral o drawer. Esta inversión cambia la sensación de “formulario técnico” a “estudio editorial”.

### 3. La selección por defecto debe reducir decisión y gasto

Tener las ocho plataformas seleccionadas por defecto es visualmente ruidoso y puede empujar a una acción cara. Aunque hoy existe confirmación, el producto debería guiar con más criterio.

La recomendación es empezar con **una plataforma recomendada** basada en la señal, más un selector silencioso de distribución. Un patrón sólido sería:

| Estado | Comportamiento recomendado |
| --- | --- |
| Primera generación | Una plataforma recomendada y un formato sugerido. |
| Generación de distribución | Acción explícita: `Crear distribución multicanal`. |
| Imagen o Both | Mostrar número estimado de operaciones y confirmación antes de generar. |
| Vídeo | Priorizar guion y storyboard; no prometer render de vídeo si no existe. |

### 4. El sistema visual necesita disciplina, no más decoración

La auditoría señala el problema técnico más claro: los colores viven dentro de los componentes. Esto dificulta la coherencia, el modo claro, el contraste y el mantenimiento.

La nueva base debe usar una sola familia tipográfica de sistema, tres radios, una escala de espaciado de 4 puntos y tokens semánticos para todas las superficies. La interfaz puede conservar el carácter oscuro, pero debe convertirse en un sistema y no en una acumulación de valores visuales.

| Elemento | Situación actual | Mejora propuesta |
| --- | --- | --- |
| Tipografía | Dos familias con abundante microtexto monoespaciado. | Una familia de sistema; mono solo para metadatos técnicos. Body a 16–17 px. |
| Color | Azul, verde y colores distintos por plataforma. | Un solo acento azul; los canales se distinguen por icono y etiqueta, no por arcoíris. |
| Superficies | Muchas cards oscuras con bordes similares. | Tres planos: canvas, material de control y superficie elevada. |
| Bordes | Casi todos los bloques están bordeados. | Agrupar primero con espacio; usar separadores solo donde reduzcan ambigüedad. |
| Movimiento | Funcional, pero sin lenguaje de transición. | Microtransiciones de 180–240 ms para selección, progreso y aparición de outputs. |

### 5. Los specialists deben ser inteligencia contextual, no una lista fija

Los cuatro specialists actuales explican el sistema, pero no intervienen visiblemente en la pieza. Para que aporten valor real, deben aparecer como una pequeña traza editorial asociada a cada output:

> **Estrategia:** priorizó la implicación para consejo y dirección.
>
> **Editorial:** convirtió la fuente en un argumento claro.
>
> **Canal:** adaptó el formato a LinkedIn.
>
> **Visual:** definió composición, jerarquía y restricciones de marca.

Esto hace tangible el valor del motor sin llenar la pantalla de tarjetas decorativas.

## Mejoras priorizadas

La prioridad se ordena por **menor coste**, **mayor utilidad práctica**, **menor complejidad** y **menor riesgo**.

| Prioridad | Mejora | Beneficio | Coste y riesgo |
| --- | --- | --- | --- |
| 1 | Crear el nuevo flujo Discover → Compose → Create → Library. | Reduce la carga cognitiva y vuelve la herramienta autoexplicativa. | Sin coste externo; cambio de UI medio. |
| 2 | Introducir tokens semánticos, una familia tipográfica y modo claro/oscuro real. | Eleva consistencia, accesibilidad y velocidad de evolución. | Sin coste externo; bajo riesgo. |
| 3 | Convertir el output en canvas editorial de revisión. | Mejora la percepción de calidad y acelera revisión/publicación. | Sin coste externo; complejidad media. |
| 4 | Reemplazar selección inicial de ocho plataformas por recomendación contextual. | Reduce gasto accidental y mejora decisión. | Sin coste externo; bajo riesgo. |
| 5 | Añadir brief editorial con objetivo, audiencia y tono antes de generar. | Produce piezas más controlables y menos genéricas. | Implica una llamada de IA adicional solo si se activa. |
| 6 | Añadir filtros, búsqueda y estados editoriales a Library. | Convierte outputs en un activo reutilizable. | Sin coste externo; complejidad media. |
| 7 | Añadir salud de fuentes y auto-scan programado. | Operación recurrente y menos mantenimiento manual. | Requiere publicación y puede implicar coste recurrente. |
| 8 | Conectar Canva. | Permite trabajo editable por diseñadores. | Requiere integración OAuth y cuenta de Canva; coste y mantenimiento externos. |

## Dirección de implementación recomendada

### Fase A — Excelencia de interfaz

Primero conviene rediseñar sin tocar la lógica validada: token layer, jerarquía, flujo por etapas, layout más silencioso, preview editorial y una biblioteca útil. Esta fase tiene el mejor retorno: eleva la percepción de calidad sin añadir dependencia externa.

### Fase B — Calidad editorial

Después, añadir un brief obligatorio o sugerido con objetivo, audiencia, tono y punto de vista. El motor debería explicar por qué recomienda un canal y permitir revisar la pieza como un activo de negocio, no solo como texto generado.

### Fase C — Operación continua

Por último, se puede configurar auto-scan, salud de feeds, calendario y Canva. Esta fase debe hacerse solo cuando el flujo editorial central esté estable y después de confirmar el coste recurrente de cualquier integración.

## Qué evitaría

No convertiría esta herramienta en una landing de marketing, ni añadiría animaciones decorativas, ni usaría más colores por plataforma, ni escondería la complejidad detrás de una falsa simplicidad. El objetivo es un **workspace editorial sereno, muy claro y muy capaz**, no un dashboard más vistoso.

## Decisión recomendada

Mi recomendación es aprobar juntas las prioridades **1 a 4**. Son las que cambian de verdad la percepción del producto y no requieren pagar ningún servicio externo. Las prioridades 5 a 8 se deberían hacer después de probar ese nuevo flujo con uso real durante unos días.
